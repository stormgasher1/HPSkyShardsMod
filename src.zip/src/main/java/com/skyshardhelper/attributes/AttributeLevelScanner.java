package com.skyshardhelper.attributes;

import com.skyshardhelper.config.SkyshardConfig;
import com.skyshardhelper.data.KnownShardsStore;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.IntConsumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Reads reptile shard levels out of item lore in the Attributes menu, e.g. "Source: Newt Shard (C35)"
// + "Attribute Level: 10 (MAX!)". We key off the (ID) since the shard name shown is a random flavour name.
public final class AttributeLevelScanner {
    private static final Logger LOGGER = LoggerFactory.getLogger("skyshardhelper");
    private static final Pattern SOURCE_PATTERN = Pattern.compile("Source:.*\\(([A-Za-z0-9]+)\\)\\s*$");
    private static final Pattern LEVEL_PATTERN = Pattern.compile("Attribute Level:\\s*(\\d+)");
    // no reliable way to detect the Attributes screen by title, so this just rescans whatever's open
    private static final int RESCAN_INTERVAL_TICKS = 30;

    private AttributeLevelScanner() {
    }

    public static void register(SkyshardConfig config, KnownShardsStore knownShards) {
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (!(screen instanceof AbstractContainerScreen<?>)) {
                return;
            }
            scan((AbstractContainerScreen<?>) screen, config, knownShards, client);

            int[] ticks = {0};
            ScreenEvents.afterTick(screen).register(tickedScreen -> {
                if (++ticks[0] % RESCAN_INTERVAL_TICKS == 0 && tickedScreen instanceof AbstractContainerScreen<?> containerScreen) {
                    scan(containerScreen, config, knownShards, client);
                }
            });
        });
    }

    private static void scan(AbstractContainerScreen<?> screen, SkyshardConfig config, KnownShardsStore knownShards,
                              Minecraft client) {
        AbstractContainerMenu menu = screen.getMenu();
        boolean changed = false;

        for (Slot slot : menu.slots) {
            ItemStack stack = slot.getItem();
            if (stack.isEmpty()) {
                continue;
            }
            ItemLore lore = stack.get(DataComponents.LORE);
            if (lore == null) {
                continue;
            }

            String shardId = null;
            Integer level = null;
            for (Component line : lore.lines()) {
                String text = line.getString();
                Matcher sourceMatch = SOURCE_PATTERN.matcher(text);
                if (sourceMatch.find()) {
                    shardId = sourceMatch.group(1);
                }
                Matcher levelMatch = LEVEL_PATTERN.matcher(text);
                if (levelMatch.find()) {
                    level = Integer.parseInt(levelMatch.group(1));
                }
            }

            // Source line appears even for shards you don't own, so no knownShards.markSeen() here.

            if (shardId != null && level != null && applyIfTracked(config, shardId, level)) {
                changed = true;
            }
        }

        if (changed) {
            config.save();
            if (client.player != null) {
                client.player.sendOverlayMessage(
                        Component.literal("[Skyshard Helper] Detected shard levels from your Attributes menu."));
            }
            LOGGER.info("Skyshard Helper: updated shard levels from Attributes menu scan");
        }
    }

    private static boolean applyIfTracked(SkyshardConfig config, String shardId, int level) {
        IntConsumer setter = switch (shardId) {
            case "C35" -> v -> config.newtLevel = v;
            case "U8" -> v -> config.salamanderLevel = v;
            case "R8" -> v -> config.lizardKingLevel = v;
            case "E5" -> v -> config.leviathanLevel = v;
            case "R9" -> v -> config.pythonLevel = v;
            case "R54" -> v -> config.kingCobraLevel = v;
            case "E32" -> v -> config.seaSerpentLevel = v;
            case "L6" -> v -> config.tiamatLevel = v;
            case "R45" -> v -> config.crocodileLevel = v;
            default -> null;
        };
        if (setter == null) {
            return false;
        }
        int current = currentLevel(config, shardId);
        if (current == level) {
            return false;
        }
        setter.accept(level);
        return true;
    }

    private static int currentLevel(SkyshardConfig config, String shardId) {
        return switch (shardId) {
            case "C35" -> config.newtLevel;
            case "U8" -> config.salamanderLevel;
            case "R8" -> config.lizardKingLevel;
            case "E5" -> config.leviathanLevel;
            case "R9" -> config.pythonLevel;
            case "R54" -> config.kingCobraLevel;
            case "E32" -> config.seaSerpentLevel;
            case "L6" -> config.tiamatLevel;
            case "R45" -> config.crocodileLevel;
            default -> -1;
        };
    }
}
