package com.skyshardhelper.inventory;

import com.skyshardhelper.data.InventoryStore;
import com.skyshardhelper.service.ShardRepository;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

// Finds owned Attribute Shards by matching item names ending in " Shard", in two places: the
// player's own inventory (always scanned) and the Hunting Box GUI (only while it's open - it's a
// real server container with a stable title, so we can match on that). Feeds InventoryStore.
public final class ShardInventoryScanner {
    private static final String SHARD_SUFFIX = " Shard";
    private static final String HUNTING_BOX_TITLE = "hunting box";
    private static final int PLAYER_SCAN_INTERVAL_TICKS = 20;
    private static final int CONTAINER_RESCAN_INTERVAL_TICKS = 20;

    private final ShardRepository repository;
    private final InventoryStore inventory;

    // both maps get merged into InventoryStore whenever either changes. huntingBoxCounts just keeps
    // whatever it last saw once the screen closes, since we can't read it again until it's reopened
    private Map<String, Integer> playerCounts = Map.of();
    private Map<String, Integer> huntingBoxCounts = Map.of();
    private int ticksUntilPlayerScan;

    private ShardInventoryScanner(ShardRepository repository, InventoryStore inventory) {
        this.repository = repository;
        this.inventory = inventory;
    }

    public static void register(ShardRepository repository, InventoryStore inventory) {
        ShardInventoryScanner scanner = new ShardInventoryScanner(repository, inventory);
        ClientTickEvents.END_CLIENT_TICK.register(scanner::tickPlayerInventory);

        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (!(screen instanceof AbstractContainerScreen<?> containerScreen) || !isHuntingBox(containerScreen)) {
                return;
            }
            scanner.scanHuntingBox(containerScreen, client);

            int[] ticks = {0};
            ScreenEvents.afterTick(screen).register(tickedScreen -> {
                if (++ticks[0] % CONTAINER_RESCAN_INTERVAL_TICKS == 0 && tickedScreen instanceof AbstractContainerScreen<?> c) {
                    scanner.scanHuntingBox(c, client);
                }
            });
        });
    }

    private static boolean isHuntingBox(AbstractContainerScreen<?> screen) {
        return screen.getTitle().getString().toLowerCase(Locale.ROOT).contains(HUNTING_BOX_TITLE);
    }

    private void tickPlayerInventory(Minecraft client) {
        if (client.player == null) {
            return;
        }
        if (ticksUntilPlayerScan-- > 0) {
            return;
        }
        ticksUntilPlayerScan = PLAYER_SCAN_INTERVAL_TICKS;

        Map<String, Integer> counts = new HashMap<>();
        for (ItemStack stack : client.player.getInventory().getNonEquipmentItems()) {
            addShardCount(stack, counts);
        }
        if (!counts.equals(playerCounts)) {
            playerCounts = counts;
            mergeAndSave();
        }
    }

    // skip the bottom slots, that's just the player's own inventory and tickPlayerInventory already covers it
    private void scanHuntingBox(AbstractContainerScreen<?> screen, Minecraft client) {
        AbstractContainerMenu menu = screen.getMenu();
        Map<String, Integer> counts = new HashMap<>();
        for (Slot slot : menu.slots) {
            if (slot.container == client.player.getInventory()) {
                continue;
            }
            addShardCount(slot.getItem(), counts);
        }
        if (!counts.equals(huntingBoxCounts)) {
            huntingBoxCounts = counts;
            mergeAndSave();
        }
    }

    private void addShardCount(ItemStack stack, Map<String, Integer> counts) {
        if (stack.isEmpty()) {
            return;
        }
        String name = stack.getHoverName().getString();
        if (!name.endsWith(SHARD_SUFFIX)) {
            return;
        }
        String shardName = name.substring(0, name.length() - SHARD_SUFFIX.length()).trim();
        repository.findByNameIgnoreCase(shardName).ifPresent(shard ->
                counts.merge(shard.id(), stack.getCount(), Integer::sum));
    }

    private void mergeAndSave() {
        Map<String, Integer> merged = new HashMap<>(playerCounts);
        huntingBoxCounts.forEach((id, qty) -> merged.merge(id, qty, Integer::sum));
        inventory.replaceAll(merged);
    }
}
