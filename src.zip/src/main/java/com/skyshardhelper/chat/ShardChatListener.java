package com.skyshardhelper.chat;

import com.skyshardhelper.config.SkyshardConfig;
import com.skyshardhelper.data.Shard;
import com.skyshardhelper.service.ShardRepository;
import com.skyshardhelper.tracking.CatchRateTracker;
import com.skyshardhelper.tracking.ShardGoalTracker;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.ChatFormatting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

// Runs the configured chat regexes against incoming messages to catch shard pickups.
public final class ShardChatListener {
    private static final Logger LOGGER = LoggerFactory.getLogger("skyshardhelper");
    // Hypixel bakes legacy "§x" codes into the message text itself, not as a proper Style.
    private static final Pattern LEGACY_FORMATTING_CODE = Pattern.compile("§.");

    private final SkyshardConfig config;
    private final ShardRepository repository;
    private final ShardGoalTracker tracker;
    private final CatchRateTracker rateTracker;
    private List<Pattern> compiledPatterns = List.of();

    private ShardChatListener(SkyshardConfig config, ShardRepository repository, ShardGoalTracker tracker,
                               CatchRateTracker rateTracker) {
        this.config = config;
        this.repository = repository;
        this.tracker = tracker;
        this.rateTracker = rateTracker;
        recompile();
    }

    public static ShardChatListener register(SkyshardConfig config, ShardRepository repository, ShardGoalTracker tracker,
                                              CatchRateTracker rateTracker) {
        ShardChatListener listener = new ShardChatListener(config, repository, tracker, rateTracker);
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> listener.onMessage(message.getString()));
        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, timestamp) ->
                listener.onMessage(message.getString()));
        return listener;
    }

    // call this after the regex list changes in the config screen
    public void recompile() {
        List<Pattern> patterns = new ArrayList<>();
        for (String raw : config.chatRegexPatterns) {
            try {
                patterns.add(Pattern.compile(raw));
            } catch (PatternSyntaxException e) {
                LOGGER.warn("Skyshard Helper: ignoring invalid chat regex pattern '{}': {}", raw, e.getMessage());
            }
        }
        this.compiledPatterns = patterns;
    }

    private void onMessage(String rawText) {
        String plainText = LEGACY_FORMATTING_CODE.matcher(rawText).replaceAll("");
        for (Pattern pattern : compiledPatterns) {
            Matcher matcher = pattern.matcher(plainText);
            if (!matcher.find()) {
                continue;
            }
            String shardName;
            try {
                shardName = matcher.group("shard");
            } catch (IllegalArgumentException e) {
                LOGGER.warn("Skyshard Helper: chat pattern '{}' has no named group 'shard', skipping", pattern.pattern());
                continue;
            }
            if (shardName == null) {
                continue;
            }
            int quantity = 1;
            try {
                String qtyGroup = matcher.group("qty");
                if (qtyGroup != null) {
                    quantity = Integer.parseInt(qtyGroup);
                }
            } catch (IllegalArgumentException e) {
                // pattern has no "qty" group - default of 1 stands
            }

            int finalQuantity = quantity;
            repository.findByNameIgnoreCase(shardName.trim())
                    .ifPresent(shard -> onShardMatched(shard, finalQuantity));
        }
    }

    private void onShardMatched(Shard shard, int quantity) {
        rateTracker.record(shard.id(), quantity);
        boolean wasComplete = tracker.isAllMaterialsComplete();
        tracker.onShardObtained(shard, quantity);
        if (!wasComplete && tracker.isAllMaterialsComplete()) {
            showCompletionTitle();
        }
    }

    private void showCompletionTitle() {
        Minecraft client = Minecraft.getInstance();
        ClientPacketListener connection = client.getConnection();
        if (connection == null) {
            return;
        }
        Shard target = tracker.selectedShard();
        String subtitleText = target != null ? "Ready to fuse " + target.name() + "!" : "All materials collected!";
        connection.setTitleText(new ClientboundSetTitleTextPacket(
                Component.literal("Materials Complete!").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD)));
        connection.setSubtitleText(new ClientboundSetSubtitleTextPacket(
                Component.literal(subtitleText).withStyle(ChatFormatting.YELLOW)));
    }
}
