package com.skyshardhelper.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Set;

// backs the Browse Shards "Missing" filter. Nothing calls markSeen yet, so in practice this stays empty.
public final class KnownShardsStore {
    private static final Logger LOGGER = LoggerFactory.getLogger("skyshardhelper");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type SET_TYPE = new TypeToken<LinkedHashSet<String>>() {
    }.getType();
    private static final String FILE_NAME = "skyshardhelper_known_shards.json";

    private final Set<String> known;

    private KnownShardsStore(Set<String> known) {
        this.known = known;
    }

    public static KnownShardsStore loadOrCreate() {
        Path path = storePath();
        if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                Set<String> loaded = GSON.fromJson(reader, SET_TYPE);
                if (loaded != null) {
                    return new KnownShardsStore(new LinkedHashSet<>(loaded));
                }
            } catch (IOException e) {
                LOGGER.error("Skyshard Helper: failed to read known-shards store, starting empty", e);
            }
        }
        return new KnownShardsStore(new LinkedHashSet<>());
    }

    public boolean isKnown(String shardId) {
        return known.contains(shardId);
    }

    public void markSeen(String shardId) {
        if (known.add(shardId)) {
            save();
        }
    }

    private void save() {
        Path path = storePath();
        try {
            Files.createDirectories(path.getParent());
            try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
                GSON.toJson(known, SET_TYPE, writer);
            }
        } catch (IOException e) {
            LOGGER.error("Skyshard Helper: failed to save known-shards store", e);
        }
    }

    private static Path storePath() {
        return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
    }
}
