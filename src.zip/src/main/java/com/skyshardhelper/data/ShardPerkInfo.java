package com.skyshardhelper.data;

// the Attribute perk text - not to be confused with Shard.name(), which is just the item's display name
public record ShardPerkInfo(String title, String description) {
}
