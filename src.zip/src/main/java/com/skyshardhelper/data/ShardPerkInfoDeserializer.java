package com.skyshardhelper.data;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Type;

// desc.json shows up in two shapes: a plain string, or the dev branch's rich-text segment array. Flattens either into one string.
public final class ShardPerkInfoDeserializer implements JsonDeserializer<ShardPerkInfo> {
    private static final Logger LOGGER = LoggerFactory.getLogger("skyshardhelper");

    @Override
    public ShardPerkInfo deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        JsonObject obj = json.getAsJsonObject();
        String title = obj.has("title") && !obj.get("title").isJsonNull() ? obj.get("title").getAsString() : "";
        JsonElement descElement = obj.get("description");
        String description;
        if (descElement == null || descElement.isJsonNull()) {
            description = "";
        } else if (descElement.isJsonArray()) {
            // Gson bails on the whole map if this throws, so one bad entry can't blank out every description
            try {
                description = renderSegments(descElement.getAsJsonArray());
            } catch (RuntimeException e) {
                LOGGER.warn("Skyshard Helper: failed to render a perk description segment array, leaving it blank: {}",
                        e.getMessage());
                description = "";
            }
        } else {
            description = descElement.getAsString();
        }
        return new ShardPerkInfo(title, description);
    }

    private static String renderSegments(JsonArray segments) {
        StringBuilder sb = new StringBuilder();
        for (JsonElement element : segments) {
            if (!element.isJsonObject()) {
                continue;
            }
            JsonObject segment = element.getAsJsonObject();
            if (segment.has("range") && segment.getAsJsonArray("range").size() >= 2) {
                JsonArray range = segment.getAsJsonArray("range");
                String unit = segment.has("unit") && !segment.get("unit").isJsonNull()
                        ? segment.get("unit").getAsString() : "";
                sb.append(formatNumber(range.get(0))).append('-').append(formatNumber(range.get(1))).append(unit);
            } else if (segment.has("t") && !segment.get("t").isJsonNull()) {
                sb.append(segment.get("t").getAsString());
            }
        }
        // adjacent segments (e.g. an icon placeholder) can leave double spaces behind
        return sb.toString().trim().replaceAll(" +", " ");
    }

    private static String formatNumber(JsonElement element) {
        double value = element.getAsDouble();
        if (value == Math.floor(value) && !Double.isInfinite(value)) {
            return String.valueOf((long) value);
        }
        return String.valueOf(value);
    }
}
