package com.skyshardhelper.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

// persisted owned-shards inventory (shardId -> quantity), shared between Ironman and Normal profiles
public final class InventoryStore {
    private static final Logger LOGGER = LoggerFactory.getLogger("skyshardhelper");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<LinkedHashMap<String, Integer>>() {
    }.getType();
    private static final String FILE_NAME = "skyshardhelper_inventory.json";

    private final Map<String, Integer> quantities;

    private InventoryStore(Map<String, Integer> quantities) {
        this.quantities = quantities;
    }

    public static InventoryStore loadOrCreate() {
        Path path = storePath();
        if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                Map<String, Integer> loaded = GSON.fromJson(reader, MAP_TYPE);
                if (loaded != null) {
                    return new InventoryStore(new LinkedHashMap<>(loaded));
                }
            } catch (IOException e) {
                LOGGER.error("Skyshard Helper: failed to read inventory, starting empty", e);
            }
        }
        return new InventoryStore(new LinkedHashMap<>());
    }

    public int get(String shardId) {
        return quantities.getOrDefault(shardId, 0);
    }

    public void set(String shardId, int quantity) {
        if (quantity <= 0) {
            quantities.remove(shardId);
        } else {
            quantities.put(shardId, quantity);
        }
        save();
    }

    public void clear() {
        quantities.clear();
        save();
    }

    // ShardInventoryScanner calls this every tick, so bail out fast when nothing actually changed
    public void replaceAll(Map<String, Integer> newQuantities) {
        Map<String, Integer> cleaned = new LinkedHashMap<>();
        newQuantities.forEach((id, qty) -> {
            if (qty > 0) {
                cleaned.put(id, qty);
            }
        });
        if (cleaned.equals(quantities)) {
            return;
        }
        quantities.clear();
        quantities.putAll(cleaned);
        save();
    }

    public Map<String, Integer> asMap() {
        return Map.copyOf(quantities);
    }

    public int shardTypeCount() {
        return quantities.size();
    }

    public void save() {
        Path path = storePath();
        try {
            Files.createDirectories(path.getParent());
            try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
                GSON.toJson(quantities, MAP_TYPE, writer);
            }
        } catch (IOException e) {
            LOGGER.error("Skyshard Helper: failed to save inventory", e);
        }
    }

    private static Path storePath() {
        return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
    }
}
