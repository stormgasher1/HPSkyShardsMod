package com.skyshardhelper.data;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// mirrors fusion-data.json's on-disk shape (recipes keyed by output quantity); toFusionData() flattens it into a FusionData
public record RawFusionData(
        Map<String, RawShard> shards,
        Map<String, Map<String, List<List<String>>>> recipes
) {
    public record RawShard(
            String name,
            String family,
            String type,
            String rarity,
            @SerializedName("fuse_amount") int fuseAmount,
            @SerializedName("internal_id") String internalId
    ) {
    }

    public FusionData toFusionData(Map<String, Double> rates) {
        Map<String, Shard> flatShards = new HashMap<>();
        for (Map.Entry<String, RawShard> entry : shards.entrySet()) {
            String id = entry.getKey();
            RawShard raw = entry.getValue();
            double rate = rates.getOrDefault(id, 0.0);
            flatShards.put(id, new Shard(id, raw.name(), raw.family(), raw.type(), raw.rarity(), raw.fuseAmount(), raw.internalId(), rate));
        }

        Map<String, List<Recipe>> flatRecipes = new HashMap<>();
        for (Map.Entry<String, Map<String, List<List<String>>>> outputEntry : recipes.entrySet()) {
            String outputId = outputEntry.getKey();
            List<Recipe> list = new ArrayList<>();
            // raw data has each combo listed both ways round, dedupe down to one Recipe
            java.util.Set<String> seenPairs = new java.util.HashSet<>();
            for (Map.Entry<String, List<List<String>>> quantityEntry : outputEntry.getValue().entrySet()) {
                int outputQuantity = Integer.parseInt(quantityEntry.getKey());
                for (List<String> pair : quantityEntry.getValue()) {
                    if (pair.size() != 2) {
                        continue;
                    }
                    String input1 = pair.get(0);
                    String input2 = pair.get(1);
                    String dedupeKey = outputQuantity + "|" + (input1.compareTo(input2) <= 0
                            ? input1 + "," + input2
                            : input2 + "," + input1);
                    if (!seenPairs.add(dedupeKey)) {
                        continue;
                    }
                    boolean isReptile = isReptileFamily(flatShards.get(input1)) || isReptileFamily(flatShards.get(input2));
                    list.add(new Recipe(new String[]{input1, input2}, outputQuantity, isReptile));
                }
            }
            flatRecipes.put(outputId, list);
        }

        return new FusionData(flatShards, flatRecipes);
    }

    private static boolean isReptileFamily(Shard shard) {
        return shard != null && shard.family() != null && shard.family().contains("Reptile");
    }
}
