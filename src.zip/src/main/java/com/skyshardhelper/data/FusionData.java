package com.skyshardhelper.data;

import java.util.List;
import java.util.Map;

// flattened shard/recipe data, same shape whether it came from the live fetch or the bundled fallback
public record FusionData(
        Map<String, Shard> shards,
        Map<String, List<Recipe>> recipes
) {
    public static FusionData empty() {
        return new FusionData(Map.of(), Map.of());
    }
}
