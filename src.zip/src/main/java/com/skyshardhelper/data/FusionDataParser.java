package com.skyshardhelper.data;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.Reader;
import java.lang.reflect.Type;
import java.util.Map;

// parses the fusion-data.json + rates.json pair; shared by both the bundled and live-fetch paths
public final class FusionDataParser {
    private static final Type RATES_TYPE = new TypeToken<Map<String, Double>>() {
    }.getType();

    private FusionDataParser() {
    }

    public static FusionData parse(Gson gson, Reader fusionDataJson, Reader ratesJson) {
        RawFusionData raw = gson.fromJson(fusionDataJson, RawFusionData.class);
        Map<String, Double> rates = gson.fromJson(ratesJson, RATES_TYPE);
        if (raw == null || raw.shards() == null) {
            return null;
        }
        return raw.toFusionData(rates != null ? rates : Map.of());
    }
}
