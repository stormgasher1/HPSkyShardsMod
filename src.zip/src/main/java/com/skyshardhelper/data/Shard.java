package com.skyshardhelper.data;

import com.google.gson.annotations.SerializedName;

// rarity is kept as a plain string - an enum here would break deserialization the moment the API adds a new one
public record Shard(
        String id,
        String name,
        String family,
        String type,
        String rarity,
        @SerializedName("fuse_amount") int fuseAmount,
        @SerializedName("internal_id") String internalId,
        double rate
) {
    public int rarityColor() {
        return switch (rarity == null ? "" : rarity.toLowerCase()) {
            case "common" -> 0xFFFFFF;
            case "uncommon" -> 0x55FF55;
            case "rare" -> 0x5555FF;
            case "epic" -> 0xAA00AA;
            case "legendary" -> 0xFFAA00;
            default -> 0xAAAAAA;
        };
    }
}
