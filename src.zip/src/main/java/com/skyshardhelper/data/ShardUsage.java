package com.skyshardhelper.data;

// reverse of a Recipe: "what does this shard get used to make", built by ShardRepository.usedIn
public record ShardUsage(String outputShardId, Recipe recipe) {
}
