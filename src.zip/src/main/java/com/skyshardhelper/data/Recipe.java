package com.skyshardhelper.data;

import com.google.gson.annotations.SerializedName;

// mirrors the recipe schema from skyshards.com's fusion-data.json
public record Recipe(
        String[] inputs,
        @SerializedName("outputQuantity") int outputQuantity,
        @SerializedName("isReptile") boolean isReptile
) {
}
