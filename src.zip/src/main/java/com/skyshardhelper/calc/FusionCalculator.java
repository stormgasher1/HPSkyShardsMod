package com.skyshardhelper.calc;

import com.skyshardhelper.data.Recipe;
import com.skyshardhelper.data.Shard;
import com.skyshardhelper.service.ShardRepository;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

// Cost-optimal fusion calculator, ported from skyshards.com. Two things it doesn't do that the
// site does: cycle nodes in the tree (buildTree just bails to a direct leaf if a shard shows up as
// its own ancestor) and coin-value mode / the Kuudra L15 rate override - Ironman/time math only.
public final class FusionCalculator {
    private static final double TOLERANCE = 1e-10;

    private final ShardRepository repository;

    public FusionCalculator(ShardRepository repository) {
        this.repository = repository;
    }

    // ownedInventory is shard id -> qty already owned (empty when "Use Inventory" is off). It gets
    // spent down as the tree is built so owned stock isn't double-counted across branches.
    public FusionResult calculate(String targetShardId, int quantity, CalculationParams params,
                                   Map<String, Integer> ownedInventory) {
        Map<String, Double> effectiveRates = computeEffectiveRates(params);
        Map<String, Double> minCosts = new HashMap<>();
        Map<String, Recipe> choices = new HashMap<>();
        computeMinCosts(effectiveRates, params, minCosts, choices);

        Map<String, Integer> ownedRemaining = new HashMap<>(ownedInventory);
        FusionNode tree = buildTree(targetShardId, Math.max(quantity, 1), choices, params, new HashSet<>(), ownedRemaining);

        Map<String, Integer> totals = new LinkedHashMap<>();
        int[] totalCrafts = {0};
        collect(tree, totals, totalCrafts);

        int totalShardsProduced;
        if (tree instanceof FusionNode.Craft craft) {
            double effectiveOutput = effectiveOutputQuantity(craft.recipe(), params.crocodileMultiplier());
            totalShardsProduced = (int) Math.round(craft.craftsNeeded() * effectiveOutput);
        } else {
            totalShardsProduced = tree.quantity();
        }

        double materialTimeHours = 0;
        for (Map.Entry<String, Integer> entry : totals.entrySet()) {
            double rate = effectiveRates.getOrDefault(entry.getKey(), 0.0);
            if (rate > 0) {
                materialTimeHours += entry.getValue() / rate;
            }
        }
        double craftTimeHours = totalCrafts[0] * params.craftPenaltyHours();
        double totalTimeHours = materialTimeHours + craftTimeHours;
        double timePerShardHours = totalShardsProduced > 0 ? totalTimeHours / totalShardsProduced : 0;

        return new FusionResult(tree, totals, totalCrafts[0], totalShardsProduced,
                craftTimeHours, totalTimeHours, timePerShardHours, effectiveRates);
    }

    // ------------------------------------------------------------ rates

    private Map<String, Double> computeEffectiveRates(CalculationParams params) {
        Map<String, Double> rates = new HashMap<>();
        for (Shard shard : repository.all()) {
            rates.put(shard.id(), effectiveRate(shard, params));
        }
        return rates;
    }

    private double effectiveRate(Shard shard, CalculationParams params) {
        String id = shard.id();
        double rate = shard.rate();

        if (rate > 0) {
            if (params.noWoodenBait() && FusionConstants.WOODEN_BAIT_SHARDS.contains(id)) {
                rate *= id.equals("L23") ? 0.1 : 0.05;
            }
            if (!FusionConstants.NO_FORTUNE_SHARDS.contains(id)) {
                rate = applyFortuneModifiers(rate, id, shard, params);
            }
        }

        if (params.excludeChameleon() && id.equals("L4")) {
            rate = 0;
        }
        return rate;
    }

    private double applyFortuneModifiers(double rate, String shardId, Shard shard, CalculationParams params) {
        double effectiveFortune = params.hunterFortune();
        double rarityBonus = switch (shard.rarity() == null ? "" : shard.rarity().toLowerCase(Locale.ROOT)) {
            case "common" -> 2.0 * params.newtLevel();
            case "uncommon" -> 2.0 * params.salamanderLevel();
            case "rare" -> (double) params.lizardKingLevel();
            case "epic" -> (double) params.leviathanLevel();
            default -> 0.0;
        };
        effectiveFortune += rarityBonus;

        Boolean blackHolePython = FusionConstants.BLACK_HOLE_SHARD.get(shardId);
        if (blackHolePython != null) {
            if (blackHolePython) {
                rate *= 1 + params.pythonMultiplier();
            }
            effectiveFortune *= 1 + params.kingCobraMultiplier();
        }

        return rate * (1 + effectiveFortune / 100.0);
    }

    private static double effectiveOutputQuantity(Recipe recipe, double crocodileMultiplier) {
        return recipe.isReptile() ? recipe.outputQuantity() * crocodileMultiplier : recipe.outputQuantity();
    }

    private static double getDirectCost(double rate) {
        return rate <= 0 ? Double.POSITIVE_INFINITY : 1.0 / rate;
    }

    // ------------------------------------------------------- min-cost solve

    private void computeMinCosts(Map<String, Double> effectiveRates, CalculationParams params,
                                  Map<String, Double> minCosts, Map<String, Recipe> choices) {
        double crocodileMultiplier = params.crocodileMultiplier();
        Collection<Shard> allShards = repository.all();

        for (Shard shard : allShards) {
            minCosts.put(shard.id(), getDirectCost(effectiveRates.getOrDefault(shard.id(), 0.0)));
            choices.put(shard.id(), null);
        }

        Map<String, List<String>> dependents = new HashMap<>();
        for (Shard shard : allShards) {
            for (Recipe recipe : repository.recipesFor(shard.id())) {
                dependents.computeIfAbsent(recipe.inputs()[0], k -> new ArrayList<>()).add(shard.id());
                dependents.computeIfAbsent(recipe.inputs()[1], k -> new ArrayList<>()).add(shard.id());
            }
        }

        Deque<String> queue = new ArrayDeque<>();
        Set<String> inQueue = new HashSet<>();
        for (Shard shard : allShards) {
            queue.add(shard.id());
            inQueue.add(shard.id());
        }

        while (!queue.isEmpty()) {
            String outputShard = queue.poll();
            inQueue.remove(outputShard);

            double currentCost = minCosts.get(outputShard);
            Recipe currentChoice = choices.get(outputShard);
            double bestCost = currentCost;
            Recipe bestRecipe = currentChoice;

            for (Recipe recipe : repository.recipesFor(outputShard)) {
                String input1 = recipe.inputs()[0];
                String input2 = recipe.inputs()[1];
                Double cost1 = minCosts.get(input1);
                Double cost2 = minCosts.get(input2);
                if (cost1 == null || cost2 == null) {
                    continue;
                }
                double totalCost = cost1 * fuseAmount(input1) + cost2 * fuseAmount(input2) + params.craftPenaltyHours();
                double costPerUnit = totalCost / effectiveOutputQuantity(recipe, crocodileMultiplier);

                if (costPerUnit < bestCost - TOLERANCE) {
                    bestCost = costPerUnit;
                    bestRecipe = recipe;
                }
            }

            if (bestCost < currentCost - TOLERANCE || bestRecipe != currentChoice) {
                minCosts.put(outputShard, bestCost);
                choices.put(outputShard, bestRecipe);
                for (String dependent : dependents.getOrDefault(outputShard, List.of())) {
                    if (inQueue.add(dependent)) {
                        queue.add(dependent);
                    }
                }
            }
        }
    }

    private int fuseAmount(String shardId) {
        return repository.findById(shardId).map(Shard::fuseAmount).orElse(1);
    }

    // ------------------------------------------------------------- tree

    // path is the cycle guard - a shard reappearing as its own ancestor just becomes a Direct leaf.
    // ownedRemaining gets mutated in place as stock is spent, on purpose, so branches share it.
    private FusionNode buildTree(String shardId, int quantity, Map<String, Recipe> choices,
                                  CalculationParams params, Set<String> path, Map<String, Integer> ownedRemaining) {
        int owned = ownedRemaining.getOrDefault(shardId, 0);
        if (owned > 0) {
            int usedFromOwned = Math.min(owned, quantity);
            ownedRemaining.put(shardId, owned - usedFromOwned);
            quantity -= usedFromOwned;
        }
        if (quantity <= 0) {
            return new FusionNode.Direct(shardId, 0);
        }

        Recipe recipe = choices.get(shardId);
        if (recipe == null || path.contains(shardId)) {
            return new FusionNode.Direct(shardId, quantity);
        }

        double effectiveOutput = effectiveOutputQuantity(recipe, params.crocodileMultiplier());
        int craftsNeeded = Math.max((int) Math.ceil(quantity / effectiveOutput), 1);

        path.add(shardId);
        String input1 = recipe.inputs()[0];
        String input2 = recipe.inputs()[1];
        FusionNode node1 = buildTree(input1, craftsNeeded * fuseAmount(input1), choices, params, path, ownedRemaining);
        FusionNode node2 = buildTree(input2, craftsNeeded * fuseAmount(input2), choices, params, path, ownedRemaining);
        path.remove(shardId);

        return new FusionNode.Craft(shardId, quantity, recipe, craftsNeeded, node1, node2);
    }

    private void collect(FusionNode node, Map<String, Integer> totals, int[] totalCrafts) {
        switch (node) {
            case FusionNode.Direct direct -> {
                if (direct.quantity() > 0) {
                    totals.merge(direct.shardId(), direct.quantity(), Integer::sum);
                }
            }
            case FusionNode.Craft craft -> {
                totalCrafts[0] += craft.craftsNeeded();
                collect(craft.input1(), totals, totalCrafts);
                collect(craft.input2(), totals, totalCrafts);
            }
        }
    }
}
