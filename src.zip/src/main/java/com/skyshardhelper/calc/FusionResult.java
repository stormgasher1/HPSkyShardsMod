package com.skyshardhelper.calc;

import java.util.Map;

// totalShardsProduced can be higher than what was asked for (crafts round up to whole batches).
// effectiveRates are the post-modifier numbers actually used, not the raw rates.json values.
public record FusionResult(
        FusionNode tree,
        Map<String, Integer> totalQuantities,
        int totalCrafts,
        int totalShardsProduced,
        double craftTimeHours,
        double totalTimeHours,
        double timePerShardHours,
        Map<String, Double> effectiveRates
) {
}
