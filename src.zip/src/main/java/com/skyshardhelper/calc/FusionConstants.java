package com.skyshardhelper.calc;

import java.util.Map;
import java.util.Set;

/** Exact ports of skyshards.com's src/constants/index.ts fortune-related tables. */
final class FusionConstants {
    private FusionConstants() {
    }

    static final Set<String> NO_FORTUNE_SHARDS = Set.of(
            "C19", "U4", "U16", "U28", "R24", "R25", "R27", "R60", "R64", "L4", "L15", "L30", "L33", "L48", "L51");

    static final Set<String> WOODEN_BAIT_SHARDS = Set.of("R29", "L23", "R59", "R23", "R49");

    /** shardId -> whether it also gets the Python rate multiplier (all get the King Cobra fortune multiplier). */
    static final Map<String, Boolean> BLACK_HOLE_SHARD = Map.ofEntries(
            Map.entry("L47", false), Map.entry("L27", false), Map.entry("L26", false), Map.entry("L17", false),
            Map.entry("E33", true), Map.entry("E29", false), Map.entry("E20", false), Map.entry("E18", true),
            Map.entry("E17", false), Map.entry("E14", false), Map.entry("R56", false), Map.entry("R49", false),
            Map.entry("R42", false), Map.entry("R39", true), Map.entry("R38", false), Map.entry("R36", true),
            Map.entry("R31", true), Map.entry("R21", false), Map.entry("R18", false), Map.entry("R6", true),
            Map.entry("U38", true), Map.entry("U36", true), Map.entry("U33", true), Map.entry("U32", true),
            Map.entry("U30", false), Map.entry("U29", false), Map.entry("U27", false), Map.entry("U18", true),
            Map.entry("U15", true), Map.entry("U12", true), Map.entry("C36", true), Map.entry("C33", true),
            Map.entry("C30", true), Map.entry("C27", false), Map.entry("C21", true), Map.entry("C20", false),
            Map.entry("C15", true), Map.entry("C14", false), Map.entry("C12", true), Map.entry("C9", true),
            Map.entry("C8", false));
}
