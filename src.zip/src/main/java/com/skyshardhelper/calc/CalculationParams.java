package com.skyshardhelper.calc;

/** Java port of skyshards.com's {@code CalculationParams} (Ironman/time-mode subset only). */
public record CalculationParams(
        int hunterFortune,
        boolean excludeChameleon,
        boolean noWoodenBait,
        int newtLevel,
        int salamanderLevel,
        int lizardKingLevel,
        int leviathanLevel,
        int pythonLevel,
        int kingCobraLevel,
        int seaSerpentLevel,
        int tiamatLevel,
        int crocodileLevel,
        double craftPenaltyHours
) {
    double tiamatMultiplier() {
        return 1 + (5.0 * tiamatLevel) / 100.0;
    }

    double seaSerpentMultiplier() {
        return 1 + ((2.0 * seaSerpentLevel) / 100.0) * tiamatMultiplier();
    }

    double crocodileMultiplier() {
        return 1 + (2.0 * crocodileLevel) / 100.0;
    }

    double pythonMultiplier() {
        return ((5.0 * pythonLevel) / 100.0) * seaSerpentMultiplier();
    }

    double kingCobraMultiplier() {
        return (kingCobraLevel / 100.0) * seaSerpentMultiplier();
    }
}
