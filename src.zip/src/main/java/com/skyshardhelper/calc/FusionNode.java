package com.skyshardhelper.calc;

import com.skyshardhelper.data.Recipe;

// One node of a fusion tree: Direct = farm/obtain it, Craft = fuse from two Recipe inputs.
public sealed interface FusionNode permits FusionNode.Direct, FusionNode.Craft {
    String shardId();

    int quantity();

    record Direct(String shardId, int quantity) implements FusionNode {
    }

    record Craft(String shardId, int quantity, Recipe recipe, int craftsNeeded,
                  FusionNode input1, FusionNode input2) implements FusionNode {
    }
}
