package com.skyshardhelper.hud;

import com.skyshardhelper.config.HudCorner;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

// Tracks every draggable HUD panel that's currently on screen, keyed by id.
public final class HudPanelRegistry {
    // Just mutates the panel's config fields, doesn't save - the drag screen saves once when you let go.
    @FunctionalInterface
    public interface PositionSetter {
        void apply(HudCorner corner, int offsetX, int offsetY);
    }

    public record Panel(String id, int x, int y, int width, int height, PositionSetter positionSetter) {
    }

    private static final Map<String, Panel> PANELS = new LinkedHashMap<>();

    private HudPanelRegistry() {
    }

    public static void update(String id, int x, int y, int width, int height, PositionSetter positionSetter) {
        PANELS.put(id, new Panel(id, x, y, width, height, positionSetter));
    }

    public static void remove(String id) {
        PANELS.remove(id);
    }

    public static Collection<Panel> all() {
        return PANELS.values();
    }
}
