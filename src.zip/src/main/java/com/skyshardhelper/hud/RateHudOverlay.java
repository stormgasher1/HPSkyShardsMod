package com.skyshardhelper.hud;

import com.skyshardhelper.config.HudCorner;
import com.skyshardhelper.config.SkyshardConfig;
import com.skyshardhelper.gui.util.Formatting;
import com.skyshardhelper.tracking.CatchRateTracker;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;

public final class RateHudOverlay {
    private static final int PADDING = 6;
    private static final int LINE_GAP = 2;

    private static final int CARD_BG = ARGB.color(215, 20, 21, 28);
    private static final int BORDER_ARGB = ARGB.color(255, 55, 57, 72);
    private static final int ACCENT_ARGB = ARGB.opaque(0x6FB7FF);
    private static final int MUTED_ARGB = ARGB.opaque(0x9A9CA8);

    private static final String PANEL_ID = "rate";
    private static final long RECOMPUTE_MS = 2_000;

    private static SkyshardConfig config;
    private static CatchRateTracker rateTracker;
    private static long cachedAtMs;
    private static String cachedHeaderText = "";
    private static String cachedSubText = "";

    private RateHudOverlay() {
    }

    public static void register(SkyshardConfig hudConfig, CatchRateTracker tracker) {
        config = hudConfig;
        rateTracker = tracker;
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("skyshardhelper", "rate_hud"),
                RateHudOverlay::render
        );
    }

    private static void render(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        if (config == null || rateTracker == null) {
            return;
        }
        if (!config.rateHudEnabled && !ShardHudOverlay.positionPreviewActive) {
            HudPanelRegistry.remove(PANEL_ID);
            return;
        }

        long now = System.currentTimeMillis();
        if (now - cachedAtMs >= RECOMPUTE_MS) {
            cachedHeaderText = Formatting.formatNumber(rateTracker.perHour()) + " shards/hr";
            cachedSubText = rateTracker.totalObtained() + " total this session";
            cachedAtMs = now;
        }
        String headerText = cachedHeaderText;
        String subText = cachedSubText;

        Minecraft client = Minecraft.getInstance();
        Font font = client.font;

        int textWidth = Math.max(font.width(headerText), font.width(subText));
        int boxWidth = textWidth + PADDING * 2;
        int lineHeight = font.lineHeight + LINE_GAP;
        int boxHeight = PADDING * 2 + lineHeight * 2 - LINE_GAP;

        int screenWidth = client.getWindow().getGuiScaledWidth();
        int screenHeight = client.getWindow().getGuiScaledHeight();
        int[] pos = anchor(config.rateHudCorner, screenWidth, screenHeight, boxWidth, boxHeight,
                config.rateHudOffsetX, config.rateHudOffsetY);
        int x = pos[0];
        int y = pos[1];

        HudPanelRegistry.update(PANEL_ID, x, y, boxWidth, boxHeight, (corner, offsetX, offsetY) -> {
            config.rateHudCorner = corner;
            config.rateHudOffsetX = offsetX;
            config.rateHudOffsetY = offsetY;
        });

        graphics.fill(x, y, x + boxWidth, y + boxHeight, CARD_BG);
        outline(graphics, x, y, x + boxWidth, y + boxHeight);
        graphics.text(font, headerText, x + PADDING, y + PADDING, ACCENT_ARGB);
        graphics.text(font, subText, x + PADDING, y + PADDING + lineHeight, MUTED_ARGB);
    }

    private static void outline(GuiGraphicsExtractor graphics, int x1, int y1, int x2, int y2) {
        graphics.fill(x1, y1, x2, y1 + 1, BORDER_ARGB);
        graphics.fill(x1, y2 - 1, x2, y2, BORDER_ARGB);
        graphics.fill(x1, y1, x1 + 1, y2, BORDER_ARGB);
        graphics.fill(x2 - 1, y1, x2, y2, BORDER_ARGB);
    }

    private static int[] anchor(HudCorner corner, int screenWidth, int screenHeight,
                                 int boxWidth, int boxHeight, int offsetX, int offsetY) {
        return switch (corner) {
            case TOP_LEFT -> new int[]{offsetX, offsetY};
            case TOP_RIGHT -> new int[]{screenWidth - boxWidth - offsetX, offsetY};
            case BOTTOM_LEFT -> new int[]{offsetX, screenHeight - boxHeight - offsetY};
            case BOTTOM_RIGHT -> new int[]{screenWidth - boxWidth - offsetX, screenHeight - boxHeight - offsetY};
        };
    }
}
