package com.skyshardhelper.hud;

import com.skyshardhelper.config.HudCorner;
import com.skyshardhelper.config.SkyshardConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ARGB;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

// The /sshs screen - drag panels around to reposition them.
public final class HudPositionScreen extends Screen {
    private static final int DIM_ARGB = ARGB.color(90, 0, 0, 0);
    private static final int HANDLE_ARGB = ARGB.opaque(0x6FB7FF);
    private static final int HANDLE_ACTIVE_ARGB = ARGB.opaque(0xFFFFFF);
    private static final int HANDLE_MARGIN = 2;

    private static final int DROPDOWN_WIDTH = 170;
    private static final int DROPDOWN_ROW_H = 18;
    private static final int CARD_BG = ARGB.color(230, 28, 29, 38);
    private static final int BORDER_ARGB = ARGB.color(255, 55, 57, 72);
    private static final int ROW_HOVER_BG = ARGB.color(235, 38, 39, 50);
    private static final int CHECK_ON_ARGB = ARGB.opaque(0x6BE07A);
    private static final int CHECK_OFF_ARGB = ARGB.opaque(0x9A9CA8);

    private record PanelChoice(Component label, BooleanSupplier isEnabled, Consumer<Boolean> setEnabled) {
    }

    private final SkyshardConfig config;
    private final List<PanelChoice> panelChoices;
    private String draggingPanelId;
    private int dragOffsetX;
    private int dragOffsetY;
    private boolean dropdownOpen;
    private int dropdownX;
    private int dropdownY;

    public HudPositionScreen(SkyshardConfig config) {
        super(Component.translatable("screen.skyshardhelper.hud_position.title"));
        this.config = config;

        List<PanelChoice> choices = new ArrayList<>();
        choices.add(new PanelChoice(Component.translatable("screen.skyshardhelper.hud_position.panel_rate"),
                () -> config.rateHudEnabled,
                value -> {
                    config.rateHudEnabled = value;
                    config.save();
                }));
        // Coins/hour panel doesn't apply on Ironman.
        if (!config.ironManView) {
            choices.add(new PanelChoice(Component.translatable("screen.skyshardhelper.hud_position.panel_money"),
                    () -> config.moneyHudEnabled,
                    value -> {
                        config.moneyHudEnabled = value;
                        config.save();
                    }));
        }
        this.panelChoices = List.copyOf(choices);
    }

    @Override
    protected void init() {
        ShardHudOverlay.positionPreviewActive = true;
        this.addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose())
                .bounds(this.width / 2 - 40, this.height - 28, 80, 20).build());

        dropdownX = this.width / 2 - DROPDOWN_WIDTH / 2;
        int buttonY = 26;
        this.addRenderableWidget(Button.builder(Component.translatable("screen.skyshardhelper.hud_position.add_panels"),
                        b -> dropdownOpen = !dropdownOpen)
                .bounds(dropdownX, buttonY, DROPDOWN_WIDTH, 20).build());
        dropdownY = buttonY + 20 + 2;
    }

    // Skips vanilla's blur+dim behind the screen, so extractRenderState's own dim-with-cutout is the only darkening.
    @Override
    public boolean isInGameUi() {
        return true;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        List<HudPanelRegistry.Panel> panels = List.copyOf(HudPanelRegistry.all());

        List<int[]> holes = new ArrayList<>();
        for (HudPanelRegistry.Panel panel : panels) {
            holes.add(new int[]{
                    panel.x() - HANDLE_MARGIN, panel.y() - HANDLE_MARGIN,
                    panel.x() + panel.width() + HANDLE_MARGIN, panel.y() + panel.height() + HANDLE_MARGIN
            });
        }
        fillExceptRects(graphics, holes, DIM_ARGB);

        String hint = Component.translatable("screen.skyshardhelper.hud_position.hint").getString();
        graphics.text(this.font, hint, this.width / 2 - this.font.width(hint) / 2, 12, 0xFFFFFF);

        for (HudPanelRegistry.Panel panel : panels) {
            int color = panel.id().equals(draggingPanelId) ? HANDLE_ACTIVE_ARGB : HANDLE_ARGB;
            drawHandleBorder(graphics, panel.x(), panel.y(), panel.width(), panel.height(), color);
        }

        super.extractRenderState(graphics, mouseX, mouseY, partialTick);

        if (dropdownOpen) {
            drawDropdown(graphics, mouseX, mouseY);
        }
    }

    private void drawDropdown(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        int height = panelChoices.size() * DROPDOWN_ROW_H;
        graphics.fill(dropdownX, dropdownY, dropdownX + DROPDOWN_WIDTH, dropdownY + height, CARD_BG);
        outline(graphics, dropdownX, dropdownY, dropdownX + DROPDOWN_WIDTH, dropdownY + height);

        for (int i = 0; i < panelChoices.size(); i++) {
            PanelChoice choice = panelChoices.get(i);
            int rowY = dropdownY + i * DROPDOWN_ROW_H;
            boolean hovered = mouseX >= dropdownX && mouseX <= dropdownX + DROPDOWN_WIDTH
                    && mouseY >= rowY && mouseY <= rowY + DROPDOWN_ROW_H;
            if (hovered) {
                graphics.fill(dropdownX, rowY, dropdownX + DROPDOWN_WIDTH, rowY + DROPDOWN_ROW_H, ROW_HOVER_BG);
            }
            boolean on = choice.isEnabled().getAsBoolean();
            String box = on ? "☑" : "☐";
            graphics.text(this.font, box + " " + choice.label().getString(), dropdownX + 5, rowY + 5,
                    on ? CHECK_ON_ARGB : CHECK_OFF_ARGB);
        }
    }

    private void outline(GuiGraphicsExtractor graphics, int x1, int y1, int x2, int y2) {
        graphics.fill(x1, y1, x2, y1 + 1, BORDER_ARGB);
        graphics.fill(x1, y2 - 1, x2, y2, BORDER_ARGB);
        graphics.fill(x1, y1, x1 + 1, y2, BORDER_ARGB);
        graphics.fill(x2 - 1, y1, x2, y2, BORDER_ARGB);
    }

    private void drawHandleBorder(GuiGraphicsExtractor graphics, int x, int y, int w, int h, int color) {
        int m = HANDLE_MARGIN;
        graphics.fill(x - m, y - m, x + w + m, y - m + 1, color);
        graphics.fill(x - m, y + h + m - 1, x + w + m, y + h + m, color);
        graphics.fill(x - m, y - m, x - m + 1, y + h + m, color);
        graphics.fill(x + w + m - 1, y - m, x + w + m, y + h + m, color);
    }

    private void fillExceptRects(GuiGraphicsExtractor graphics, List<int[]> holes, int color) {
        List<int[]> regions = new ArrayList<>();
        regions.add(new int[]{0, 0, this.width, this.height});
        for (int[] hole : holes) {
            List<int[]> next = new ArrayList<>();
            for (int[] region : regions) {
                next.addAll(subtract(region, hole));
            }
            regions = next;
        }
        for (int[] region : regions) {
            graphics.fill(region[0], region[1], region[2], region[3], color);
        }
    }

    private static List<int[]> subtract(int[] region, int[] hole) {
        int rx1 = region[0], ry1 = region[1], rx2 = region[2], ry2 = region[3];
        int hx1 = hole[0], hy1 = hole[1], hx2 = hole[2], hy2 = hole[3];
        if (hx2 <= rx1 || hx1 >= rx2 || hy2 <= ry1 || hy1 >= ry2) {
            return List.of(region);
        }
        List<int[]> pieces = new ArrayList<>();
        if (hy1 > ry1) {
            pieces.add(new int[]{rx1, ry1, rx2, Math.min(hy1, ry2)});
        }
        if (hy2 < ry2) {
            pieces.add(new int[]{rx1, Math.max(hy2, ry1), rx2, ry2});
        }
        int midTop = Math.max(ry1, hy1);
        int midBottom = Math.min(ry2, hy2);
        if (midTop < midBottom) {
            if (hx1 > rx1) {
                pieces.add(new int[]{rx1, midTop, Math.min(hx1, rx2), midBottom});
            }
            if (hx2 < rx2) {
                pieces.add(new int[]{Math.max(hx2, rx1), midTop, rx2, midBottom});
            }
        }
        return pieces;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (dropdownOpen && isOverDropdown(event.x(), event.y())) {
            handleDropdownClick(event.y());
            return true;
        }
        boolean handled = super.mouseClicked(event, doubleClick);
        if (handled) {
            return true;
        }
        if (dropdownOpen) {
            dropdownOpen = false;
        }
        if (event.button() == 0) {
            for (HudPanelRegistry.Panel panel : HudPanelRegistry.all()) {
                if (isOverPanel(panel, event.x(), event.y())) {
                    draggingPanelId = panel.id();
                    dragOffsetX = (int) event.x() - panel.x();
                    dragOffsetY = (int) event.y() - panel.y();
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isOverDropdown(double mouseX, double mouseY) {
        int height = panelChoices.size() * DROPDOWN_ROW_H;
        return mouseX >= dropdownX && mouseX <= dropdownX + DROPDOWN_WIDTH
                && mouseY >= dropdownY && mouseY <= dropdownY + height;
    }

    private void handleDropdownClick(double mouseY) {
        int index = (int) ((mouseY - dropdownY) / DROPDOWN_ROW_H);
        if (index >= 0 && index < panelChoices.size()) {
            PanelChoice choice = panelChoices.get(index);
            choice.setEnabled().accept(!choice.isEnabled().getAsBoolean());
        }
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (draggingPanelId != null) {
            findDraggingPanel().ifPresent(panel ->
                    moveTo(panel, (int) event.x() - dragOffsetX, (int) event.y() - dragOffsetY));
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (draggingPanelId != null) {
            draggingPanelId = null;
            config.save();
            return true;
        }
        return super.mouseReleased(event);
    }

    private java.util.Optional<HudPanelRegistry.Panel> findDraggingPanel() {
        return HudPanelRegistry.all().stream().filter(p -> p.id().equals(draggingPanelId)).findFirst();
    }

    private boolean isOverPanel(HudPanelRegistry.Panel panel, double mouseX, double mouseY) {
        return mouseX >= panel.x() && mouseX <= panel.x() + panel.width()
                && mouseY >= panel.y() && mouseY <= panel.y() + panel.height();
    }

    // Clamp to screen, then figure out the nearest corner + offset to save back.
    private void moveTo(HudPanelRegistry.Panel panel, int boxX, int boxY) {
        int boxWidth = panel.width();
        int boxHeight = panel.height();

        boxX = Math.max(0, Math.min(this.width - boxWidth, boxX));
        boxY = Math.max(0, Math.min(this.height - boxHeight, boxY));

        boolean left = boxX + boxWidth / 2 < this.width / 2;
        boolean top = boxY + boxHeight / 2 < this.height / 2;

        HudCorner corner = top
                ? (left ? HudCorner.TOP_LEFT : HudCorner.TOP_RIGHT)
                : (left ? HudCorner.BOTTOM_LEFT : HudCorner.BOTTOM_RIGHT);
        int offsetX = Math.max(0, left ? boxX : this.width - boxX - boxWidth);
        int offsetY = Math.max(0, top ? boxY : this.height - boxY - boxHeight);

        panel.positionSetter().apply(corner, offsetX, offsetY);
    }

    @Override
    public void onClose() {
        ShardHudOverlay.positionPreviewActive = false;
        config.save();
        this.minecraft.setScreenAndShow(null);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
