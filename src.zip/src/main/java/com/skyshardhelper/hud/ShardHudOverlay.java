package com.skyshardhelper.hud;

import com.skyshardhelper.calc.FusionResult;
import com.skyshardhelper.config.HudCorner;
import com.skyshardhelper.config.SkyshardConfig;
import com.skyshardhelper.data.Shard;
import com.skyshardhelper.gui.util.ShardIcons;
import com.skyshardhelper.service.ShardRepository;
import com.skyshardhelper.tracking.ShardGoalTracker;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

// Goal HUD: progress bar + checklist of what's still needed.
public final class ShardHudOverlay {
    private static final int PADDING = 6;
    private static final int LINE_GAP = 2;
    private static final int MAX_MATERIAL_LINES = 6;
    private static final int ICON_SIZE = 12;
    private static final int ICON_GAP = 4;
    private static final int BAR_HEIGHT = 3;

    private static final int CARD_BG = ARGB.color(215, 20, 21, 28);
    private static final int BORDER_ARGB = ARGB.color(255, 55, 57, 72);
    private static final int MUTED_ARGB = ARGB.opaque(0x9A9CA8);
    private static final int ACCENT_ARGB = ARGB.opaque(0x6FB7FF);
    private static final int DONE_ARGB = ARGB.opaque(0x6BE07A);
    private static final int BAR_TRACK_ARGB = ARGB.color(255, 45, 46, 58);

    private static SkyshardConfig config;
    private static ShardGoalTracker tracker;
    private static ShardRepository repository;

    // Flips on while the position screen is open, so the panel still renders (with placeholder text) even with no active goal.
    static volatile boolean positionPreviewActive = false;

    private static final String PANEL_ID = "goal";
    private static final long MATERIAL_LINES_RECOMPUTE_MS = 250;

    private static FusionResult cachedMaterialLinesResult;
    private static long cachedMaterialLinesAtMs;
    private static List<Line> cachedMaterialLines = List.of();

    private ShardHudOverlay() {
    }

    public static void register(SkyshardConfig hudConfig, ShardGoalTracker goalTracker, ShardRepository shardRepository) {
        config = hudConfig;
        tracker = goalTracker;
        repository = shardRepository;
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("skyshardhelper", "hud"),
                ShardHudOverlay::render
        );
    }

    private static void render(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        if (config == null || tracker == null || !config.hudEnabled) {
            HudPanelRegistry.remove(PANEL_ID);
            return;
        }
        boolean active = tracker.isActive();
        if (!active && !positionPreviewActive) {
            HudPanelRegistry.remove(PANEL_ID);
            return;
        }

        List<Line> lines = new ArrayList<>();
        double fraction;
        if (active) {
            Shard shard = tracker.selectedShard();
            if (shard == null) {
                HudPanelRegistry.remove(PANEL_ID);
                return;
            }
            boolean complete = tracker.isComplete();
            String headerText = complete
                    ? shard.name() + "  Complete!"
                    : shard.name() + "  " + tracker.currentAmount() + " / " + tracker.targetAmount();
            lines.add(new Line(shard.id(), headerText, complete ? DONE_ARGB : ARGB.opaque(shard.rarityColor())));
            fraction = tracker.targetAmount() > 0
                    ? Math.min(1.0, tracker.currentAmount() / (double) tracker.targetAmount())
                    : 0;
            lines.addAll(materialLines());
        } else {
            lines.add(new Line(null, "Preview  12 / 48", ACCENT_ARGB));
            lines.add(new Line(null, "3/64 Sample Material", MUTED_ARGB));
            fraction = 0.25;
        }

        Minecraft client = Minecraft.getInstance();
        Font font = client.font;

        int textWidth = 0;
        for (Line line : lines) {
            textWidth = Math.max(textWidth, font.width(line.text()));
        }
        int boxWidth = ICON_SIZE + ICON_GAP + textWidth + PADDING * 2;
        int lineHeight = Math.max(font.lineHeight, ICON_SIZE) + LINE_GAP;
        int boxHeight = PADDING + lines.size() * lineHeight + BAR_HEIGHT + LINE_GAP + PADDING;

        int screenWidth = client.getWindow().getGuiScaledWidth();
        int screenHeight = client.getWindow().getGuiScaledHeight();
        int[] pos = anchor(config.hudCorner, screenWidth, screenHeight, boxWidth, boxHeight, config.hudOffsetX, config.hudOffsetY);
        int x = pos[0];
        int y = pos[1];

        HudPanelRegistry.update(PANEL_ID, x, y, boxWidth, boxHeight, (corner, offsetX, offsetY) -> {
            config.hudCorner = corner;
            config.hudOffsetX = offsetX;
            config.hudOffsetY = offsetY;
        });

        graphics.fill(x, y, x + boxWidth, y + boxHeight, CARD_BG);
        outline(graphics, x, y, x + boxWidth, y + boxHeight);

        int cursorY = y + PADDING;
        Line header = lines.get(0);
        drawIconRow(graphics, font, header, x + PADDING, cursorY, lineHeight);
        cursorY += lineHeight;

        int barX = x + PADDING;
        int barWidth = boxWidth - PADDING * 2;
        graphics.fill(barX, cursorY, barX + barWidth, cursorY + BAR_HEIGHT, BAR_TRACK_ARGB);
        int filledWidth = (int) Math.round(barWidth * fraction);
        if (filledWidth > 0) {
            graphics.fill(barX, cursorY, barX + filledWidth, cursorY + BAR_HEIGHT, header.color());
        }
        cursorY += BAR_HEIGHT + LINE_GAP;

        for (int i = 1; i < lines.size(); i++) {
            drawIconRow(graphics, font, lines.get(i), x + PADDING, cursorY, lineHeight);
            cursorY += lineHeight;
        }
    }

    private static void drawIconRow(GuiGraphicsExtractor graphics, Font font, Line line, int x, int y, int rowHeight) {
        if (line.shardId() != null) {
            ShardIcons.draw(graphics, line.shardId(), x, y + (rowHeight - LINE_GAP - ICON_SIZE) / 2, ICON_SIZE);
        }
        int textY = y + (rowHeight - LINE_GAP - font.lineHeight) / 2;
        graphics.text(font, line.text(), x + ICON_SIZE + ICON_GAP, textY, line.color());
    }

    private static void outline(GuiGraphicsExtractor graphics, int x1, int y1, int x2, int y2) {
        graphics.fill(x1, y1, x2, y1 + 1, BORDER_ARGB);
        graphics.fill(x1, y2 - 1, x2, y2, BORDER_ARGB);
        graphics.fill(x1, y1, x1 + 1, y2, BORDER_ARGB);
        graphics.fill(x2 - 1, y1, x2, y2, BORDER_ARGB);
    }

    private static List<Line> materialLines() {
        FusionResult result = tracker.fusionResult();
        if (result == null || result.totalQuantities().isEmpty()) {
            return List.of();
        }

        long now = System.currentTimeMillis();
        if (result == cachedMaterialLinesResult && now - cachedMaterialLinesAtMs < MATERIAL_LINES_RECOMPUTE_MS) {
            return cachedMaterialLines;
        }

        List<Map.Entry<String, Integer>> remaining = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : result.totalQuantities().entrySet()) {
            int needed = entry.getValue();
            int obtained = tracker.obtainedPerLeaf().getOrDefault(entry.getKey(), 0);
            if (obtained < needed) {
                remaining.add(entry);
            }
        }
        remaining.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

        List<Line> lines = new ArrayList<>();
        int shown = 0;
        for (Map.Entry<String, Integer> entry : remaining) {
            if (shown >= MAX_MATERIAL_LINES) {
                lines.add(new Line(null, "+" + (remaining.size() - shown) + " more...", MUTED_ARGB));
                break;
            }
            String shardId = entry.getKey();
            int needed = entry.getValue();
            int obtained = tracker.obtainedPerLeaf().getOrDefault(shardId, 0);
            String name = repository.findById(shardId).map(Shard::name).orElse(shardId);
            lines.add(new Line(shardId, obtained + "/" + needed + " " + name, MUTED_ARGB));
            shown++;
        }
        cachedMaterialLinesResult = result;
        cachedMaterialLinesAtMs = now;
        cachedMaterialLines = lines;
        return lines;
    }

    private record Line(String shardId, String text, int color) {
    }

    private static int[] anchor(HudCorner corner, int screenWidth, int screenHeight,
                                 int boxWidth, int boxHeight, int offsetX, int offsetY) {
        return switch (corner) {
            case TOP_LEFT -> new int[]{offsetX, offsetY};
            case TOP_RIGHT -> new int[]{screenWidth - boxWidth - offsetX, offsetY};
            case BOTTOM_LEFT -> new int[]{offsetX, screenHeight - boxHeight - offsetY};
            case BOTTOM_RIGHT -> new int[]{screenWidth - boxWidth - offsetX, screenHeight - boxHeight - offsetY};
        };
    }
}
