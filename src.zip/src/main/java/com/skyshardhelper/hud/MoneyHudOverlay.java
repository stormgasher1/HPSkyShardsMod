package com.skyshardhelper.hud;

import com.skyshardhelper.config.HudCorner;
import com.skyshardhelper.config.SkyshardConfig;
import com.skyshardhelper.data.Shard;
import com.skyshardhelper.gui.util.Formatting;
import com.skyshardhelper.service.BazaarPriceCache;
import com.skyshardhelper.service.ShardRepository;
import com.skyshardhelper.tracking.CatchRateTracker;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;

// Coins/hour panel, priced off the live Bazaar. Hidden on Ironman.
public final class MoneyHudOverlay {
    private static final int PADDING = 6;
    private static final int LINE_GAP = 2;

    private static final int CARD_BG = ARGB.color(215, 20, 21, 28);
    private static final int BORDER_ARGB = ARGB.color(255, 55, 57, 72);
    private static final int ACCENT_ARGB = ARGB.opaque(0xF5D76E);
    private static final int MUTED_ARGB = ARGB.opaque(0x9A9CA8);

    private static final String PANEL_ID = "money";
    private static final long RECOMPUTE_MS = 2_000; // no need to recompute every frame

    private static SkyshardConfig config;
    private static CatchRateTracker rateTracker;
    private static ShardRepository repository;
    private static BazaarPriceCache bazaarPriceCache;
    private static long cachedAtMs;
    private static String cachedHeaderText = "";

    private MoneyHudOverlay() {
    }

    public static void register(SkyshardConfig hudConfig, CatchRateTracker tracker, ShardRepository shardRepository,
                                 BazaarPriceCache priceCache) {
        config = hudConfig;
        rateTracker = tracker;
        repository = shardRepository;
        bazaarPriceCache = priceCache;
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("skyshardhelper", "money_hud"),
                MoneyHudOverlay::render
        );
    }

    private static void render(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        if (config == null || rateTracker == null || repository == null || bazaarPriceCache == null) {
            return;
        }
        if (config.ironManView) {
            HudPanelRegistry.remove(PANEL_ID);
            return;
        }
        if (!config.moneyHudEnabled && !ShardHudOverlay.positionPreviewActive) {
            HudPanelRegistry.remove(PANEL_ID);
            return;
        }

        long now = System.currentTimeMillis();
        if (now - cachedAtMs >= RECOMPUTE_MS) {
            double perHour = rateTracker.moneyPerHour(shardId -> repository.findById(shardId)
                    .map(Shard::internalId)
                    .map(bazaarPriceCache::sellPriceFor)
                    .orElse(0.0));
            cachedHeaderText = Formatting.formatNumber(perHour) + " coins/hr";
            cachedAtMs = now;
        }
        String headerText = cachedHeaderText;
        String subText = "Bazaar sell value, this session";

        Minecraft client = Minecraft.getInstance();
        Font font = client.font;

        int textWidth = Math.max(font.width(headerText), font.width(subText));
        int boxWidth = textWidth + PADDING * 2;
        int lineHeight = font.lineHeight + LINE_GAP;
        int boxHeight = PADDING * 2 + lineHeight * 2 - LINE_GAP;

        int screenWidth = client.getWindow().getGuiScaledWidth();
        int screenHeight = client.getWindow().getGuiScaledHeight();
        int[] pos = anchor(config.moneyHudCorner, screenWidth, screenHeight, boxWidth, boxHeight,
                config.moneyHudOffsetX, config.moneyHudOffsetY);
        int x = pos[0];
        int y = pos[1];

        HudPanelRegistry.update(PANEL_ID, x, y, boxWidth, boxHeight, (corner, offsetX, offsetY) -> {
            config.moneyHudCorner = corner;
            config.moneyHudOffsetX = offsetX;
            config.moneyHudOffsetY = offsetY;
        });

        graphics.fill(x, y, x + boxWidth, y + boxHeight, CARD_BG);
        outline(graphics, x, y, x + boxWidth, y + boxHeight);
        graphics.text(font, headerText, x + PADDING, y + PADDING, ACCENT_ARGB);
        graphics.text(font, subText, x + PADDING, y + PADDING + lineHeight, MUTED_ARGB);
    }

    private static void outline(GuiGraphicsExtractor graphics, int x1, int y1, int x2, int y2) {
        graphics.fill(x1, y1, x2, y1 + 1, BORDER_ARGB);
        graphics.fill(x1, y2 - 1, x2, y2, BORDER_ARGB);
        graphics.fill(x1, y1, x1 + 1, y2, BORDER_ARGB);
        graphics.fill(x2 - 1, y1, x2, y2, BORDER_ARGB);
    }

    private static int[] anchor(HudCorner corner, int screenWidth, int screenHeight,
                                 int boxWidth, int boxHeight, int offsetX, int offsetY) {
        return switch (corner) {
            case TOP_LEFT -> new int[]{offsetX, offsetY};
            case TOP_RIGHT -> new int[]{screenWidth - boxWidth - offsetX, offsetY};
            case BOTTOM_LEFT -> new int[]{offsetX, screenHeight - boxHeight - offsetY};
            case BOTTOM_RIGHT -> new int[]{screenWidth - boxWidth - offsetX, screenHeight - boxHeight - offsetY};
        };
    }
}
