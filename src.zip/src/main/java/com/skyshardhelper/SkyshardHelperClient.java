package com.skyshardhelper;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.skyshardhelper.attributes.AttributeLevelScanner;
import com.skyshardhelper.chat.ShardChatListener;
import com.skyshardhelper.config.SkyshardConfig;
import com.skyshardhelper.data.InventoryStore;
import com.skyshardhelper.data.KnownShardsStore;
import com.skyshardhelper.gui.ShardCalculatorScreen;
import com.skyshardhelper.gui.util.DynamicShardIconLoader;
import com.skyshardhelper.gui.util.IconCache;
import com.skyshardhelper.hud.HudPositionScreen;
import com.skyshardhelper.hud.MoneyHudOverlay;
import com.skyshardhelper.hud.RateHudOverlay;
import com.skyshardhelper.hud.ShardHudOverlay;
import com.skyshardhelper.inventory.ShardInventoryScanner;
import com.skyshardhelper.scoreboard.IronmanScoreboardScanner;
import com.skyshardhelper.service.BazaarPriceCache;
import com.skyshardhelper.service.ShardRepository;
import com.skyshardhelper.tracking.CatchRateTracker;
import com.skyshardhelper.tracking.ShardGoalTracker;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public final class SkyshardHelperClient implements ClientModInitializer {
    public static final String MOD_ID = "skyshardhelper";
    private static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final ShardRepository REPOSITORY = new ShardRepository();
    public static final ShardGoalTracker TRACKER = new ShardGoalTracker();
    public static final CatchRateTracker RATE_TRACKER = new CatchRateTracker();
    public static final BazaarPriceCache BAZAAR_PRICES = new BazaarPriceCache();
    public static SkyshardConfig CONFIG;
    public static InventoryStore INVENTORY;
    public static KnownShardsStore KNOWN_SHARDS;

    private static final KeyMapping.Category KEY_CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));

    private static ShardChatListener chatListener;
    private static KeyMapping openScreenKey;
    private static ScheduledExecutorService syncScheduler;

    // set by /sshs, picked up next tick - doing it immediately races with the chat screen closing itself
    private static volatile boolean openHudPositionRequested;

    @Override
    public void onInitializeClient() {
        CONFIG = SkyshardConfig.loadOrCreate();
        INVENTORY = InventoryStore.loadOrCreate();
        KNOWN_SHARDS = KnownShardsStore.loadOrCreate();
        REPOSITORY.loadFallback();

        if (CONFIG.apiSyncEnabled) {
            REPOSITORY.refreshFromApi(CONFIG);
            BAZAAR_PRICES.refresh(CONFIG.hypixelApiKey);
            IconCache.checkForUpdates(currentBranch());
        }

        chatListener = ShardChatListener.register(CONFIG, REPOSITORY, TRACKER, RATE_TRACKER);
        ShardHudOverlay.register(CONFIG, TRACKER, REPOSITORY);
        RateHudOverlay.register(CONFIG, RATE_TRACKER);
        MoneyHudOverlay.register(CONFIG, RATE_TRACKER, REPOSITORY, BAZAAR_PRICES);
        AttributeLevelScanner.register(CONFIG, KNOWN_SHARDS);
        IronmanScoreboardScanner.register(CONFIG);
        ShardInventoryScanner.register(REPOSITORY, INVENTORY);

        openScreenKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.skyshardhelper.open_screen",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                KEY_CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openScreenKey.consumeClick()) {
                client.setScreenAndShow(new ShardCalculatorScreen(REPOSITORY, CONFIG, INVENTORY, KNOWN_SHARDS, TRACKER));
            }
            if (openHudPositionRequested) {
                openHudPositionRequested = false;
                client.setScreenAndShow(new HudPositionScreen(CONFIG));
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommands.literal("sshs")
                        .executes(context -> requestHudPositionScreen())
                        .then(ClientCommands.literal("gui")
                                .executes(context -> requestHudPositionScreen()))
                        .then(ClientCommands.literal("apikey")
                                .executes(context -> clearApiKey(context.getSource()))
                                .then(ClientCommands.argument("key", StringArgumentType.greedyString())
                                        .executes(context -> setApiKey(context.getSource(),
                                                StringArgumentType.getString(context, "key")))))));

        startSyncScheduler();

        LOGGER.info("Skyshard Helper initialized");
    }

    private static void startSyncScheduler() {
        syncScheduler = Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, "skyshardhelper-sync");
            thread.setDaemon(true);
            return thread;
        });
        int intervalMinutes = Math.max(1, CONFIG.syncIntervalMinutes);
        syncScheduler.scheduleWithFixedDelay(() -> {
            if (CONFIG.apiSyncEnabled) {
                REPOSITORY.refreshFromApi(CONFIG);
                BAZAAR_PRICES.refresh(CONFIG.hypixelApiKey);
                IconCache.checkForUpdates(currentBranch());
            }
        }, intervalMinutes, intervalMinutes, TimeUnit.MINUTES);
    }

    // Called when the sync interval slider changes. Just re-times the scheduler, no immediate
    // fetch since the slider fires repeatedly while dragging.
    public static void onSyncIntervalChanged() {
        if (syncScheduler != null) {
            syncScheduler.shutdownNow();
        }
        startSyncScheduler();
    }

    // "Enable API sync" toggle - re-times the scheduler and, if now on, syncs right away instead of waiting for the interval.
    public static void onApiSyncEnabledChanged() {
        onSyncIntervalChanged();
        if (CONFIG.apiSyncEnabled) {
            REPOSITORY.refreshFromApi(CONFIG);
            BAZAAR_PRICES.refresh(CONFIG.hypixelApiKey);
            IconCache.checkForUpdates(currentBranch());
        }
    }

    private static int requestHudPositionScreen() {
        openHudPositionRequested = true;
        return 1;
    }

    private static int setApiKey(FabricClientCommandSource source, String key) {
        String trimmed = key.trim();
        if (trimmed.isEmpty()) {
            return clearApiKey(source);
        }
        CONFIG.hypixelApiKey = trimmed;
        CONFIG.save();
        // don't echo the key back into chat/logs
        source.sendFeedback(Component.literal("[Skyshard Helper] Hypixel API key set.").withStyle(ChatFormatting.GREEN));
        if (CONFIG.apiSyncEnabled) {
            BAZAAR_PRICES.refresh(CONFIG.hypixelApiKey);
        }
        return 1;
    }

    private static int clearApiKey(FabricClientCommandSource source) {
        CONFIG.hypixelApiKey = null;
        CONFIG.save();
        source.sendFeedback(Component.literal("[Skyshard Helper] Hypixel API key cleared.").withStyle(ChatFormatting.YELLOW));
        return 1;
    }

    private static String currentBranch() {
        return CONFIG.devVersionEnabled ? "dev" : "master";
    }

    public static void onChatPatternsChanged() {
        if (chatListener != null) {
            chatListener.recompile();
        }
    }

    // dev version toggle: re-sync and drop cached icons so they re-fetch from the other branch
    public static void onDevVersionChanged() {
        DynamicShardIconLoader.clearCache();
        if (CONFIG.apiSyncEnabled) {
            REPOSITORY.refreshFromApi(CONFIG);
            IconCache.checkForUpdates(currentBranch());
        }
    }
}
