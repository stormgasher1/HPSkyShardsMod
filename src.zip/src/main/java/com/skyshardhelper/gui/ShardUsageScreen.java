package com.skyshardhelper.gui;

import com.skyshardhelper.data.Shard;
import com.skyshardhelper.data.ShardUsage;
import com.skyshardhelper.gui.util.ShardIcons;
import com.skyshardhelper.service.ShardRepository;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ARGB;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// Right-click a shard in the browser to see every recipe that consumes it, as "icon + icon = icon".
// One level deep - clicking a result opens a new screen for that output shard instead of nesting.
public final class ShardUsageScreen extends Screen {
    private static final int PADDING = 8;
    private static final int ICON_SIZE = 20;
    private static final int ROW_HEIGHT = 30;
    private static final int ROW_GAP = 4;

    private static final int PANEL_BG = ARGB.color(210, 18, 19, 26);
    private static final int ROW_BG = ARGB.color(235, 38, 39, 50);
    private static final int BORDER = ARGB.color(255, 55, 57, 72);
    private static final int TEXT = ARGB.opaque(0xEDEDED);
    private static final int MUTED = ARGB.opaque(0x9A9CA8);

    private record Row(String otherInputId, String outputId, int screenX, int screenY, int width) {
    }

    private final Screen parent;
    private final ShardRepository repository;
    private final String rootShardId;
    private final List<ShardUsage> usages;

    private int listTop;
    private int listBottom;
    private int scroll;
    private int contentHeight;
    private final List<Row> lastRows = new ArrayList<>();

    // set during row rendering if the mouse is over one of the icons, read once after the loop
    private String hoveredTooltipShardId;

    public ShardUsageScreen(Screen parent, ShardRepository repository, String rootShardId) {
        super(Component.translatable("screen.skyshardhelper.shard_usage.title"));
        this.parent = parent;
        this.repository = repository;
        this.rootShardId = rootShardId;
        this.usages = repository.usedIn(rootShardId);
    }

    @Override
    protected void init() {
        this.addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose())
                .bounds(this.width - PADDING - 80, this.height - 24, 80, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);

        Shard rootShard = repository.findById(rootShardId).orElse(null);
        String rootName = rootShard != null ? rootShard.name() : rootShardId;
        graphics.centeredText(this.font, Component.literal("Used In: " + rootName), this.width / 2, 8, 0xFFFFFF);

        int x = PADDING + 4;
        int width = this.width - 2 * (PADDING + 4);
        listTop = 28;
        listBottom = this.height - 32;

        graphics.fill(x - 4, listTop - 4, x + width + 4, listBottom, PANEL_BG);
        outline(graphics, x - 4, listTop - 4, x + width + 4, listBottom, BORDER);

        if (usages.isEmpty()) {
            graphics.text(this.font, "Not used as an ingredient in any known recipe.", x + 4, listTop + 6, MUTED);
            lastRows.clear();
            return;
        }

        lastRows.clear();
        hoveredTooltipShardId = null;
        graphics.enableScissor(x, listTop, x + width, listBottom);
        int y = listTop - scroll;
        for (ShardUsage usage : usages) {
            if (y + ROW_HEIGHT >= listTop && y <= listBottom) {
                String otherInputId = usage.recipe().inputs()[0].equals(rootShardId)
                        ? usage.recipe().inputs()[1] : usage.recipe().inputs()[0];
                boolean hovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + ROW_HEIGHT - 2;
                renderEquationRow(graphics, x, y, width, hovered, rootShardId, otherInputId, usage.outputShardId(),
                        mouseX, mouseY);
                lastRows.add(new Row(otherInputId, usage.outputShardId(), x, y, width));
            }
            y += ROW_HEIGHT + ROW_GAP;
        }
        contentHeight = usages.size() * (ROW_HEIGHT + ROW_GAP) - ROW_GAP;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentHeight - (listBottom - listTop))));
        graphics.disableScissor();

        if (hoveredTooltipShardId != null) {
            graphics.setComponentTooltipForNextFrame(this.font, tooltipFor(hoveredTooltipShardId), mouseX, mouseY);
        }
    }

    private List<Component> tooltipFor(String shardId) {
        Shard shard = repository.findById(shardId).orElse(null);
        List<Component> tooltip = new ArrayList<>();
        if (shard != null) {
            tooltip.add(Component.literal(shard.name()).withStyle(s -> s.withColor(shard.rarityColor())));
            tooltip.add(Component.literal(capitalize(shard.rarity()) + " · " + shard.type()).withStyle(ChatFormatting.GRAY));
        } else {
            tooltip.add(Component.literal(shardId));
        }
        repository.findPerk(shardId).ifPresent(perk -> {
            tooltip.add(Component.literal(perk.title()).withStyle(ChatFormatting.YELLOW));
            tooltip.add(Component.literal(perk.description()));
        });
        return tooltip;
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) {
            return s;
        }
        return s.substring(0, 1).toUpperCase(Locale.ROOT) + s.substring(1);
    }

    private void renderEquationRow(GuiGraphicsExtractor graphics, int x, int y, int width, boolean hovered,
                                    String inputA, String inputB, String outputId, int mouseX, int mouseY) {
        graphics.fill(x, y, x + width, y + ROW_HEIGHT - 2, hovered ? ROW_BG : PANEL_BG);

        int cx = x + 8;
        int iconY = y + (ROW_HEIGHT - 2 - ICON_SIZE) / 2;
        checkIconHover(inputA, cx, iconY, mouseX, mouseY);
        ShardIcons.draw(graphics, inputA, cx, iconY, ICON_SIZE);
        cx += ICON_SIZE + 6;
        graphics.text(this.font, "+", cx, y + (ROW_HEIGHT - 2 - this.font.lineHeight) / 2, MUTED);
        cx += this.font.width("+") + 6;
        checkIconHover(inputB, cx, iconY, mouseX, mouseY);
        ShardIcons.draw(graphics, inputB, cx, iconY, ICON_SIZE);
        cx += ICON_SIZE + 6;
        graphics.text(this.font, "=", cx, y + (ROW_HEIGHT - 2 - this.font.lineHeight) / 2, MUTED);
        cx += this.font.width("=") + 6;
        checkIconHover(outputId, cx, iconY, mouseX, mouseY);
        ShardIcons.draw(graphics, outputId, cx, iconY, ICON_SIZE);
        cx += ICON_SIZE + 6;

        Shard output = repository.findById(outputId).orElse(null);
        String outputName = output != null ? output.name() : outputId;
        int outputColor = output != null ? ARGB.opaque(output.rarityColor()) : TEXT;
        graphics.text(this.font, outputName, cx, y + (ROW_HEIGHT - 2 - this.font.lineHeight) / 2, outputColor);
    }

    private void checkIconHover(String shardId, int iconX, int iconY, int mouseX, int mouseY) {
        if (mouseX >= iconX && mouseX <= iconX + ICON_SIZE && mouseY >= iconY && mouseY <= iconY + ICON_SIZE) {
            hoveredTooltipShardId = shardId;
        }
    }

    private void outline(GuiGraphicsExtractor graphics, int x1, int y1, int x2, int y2, int color) {
        graphics.fill(x1, y1, x2, y1 + 1, color);
        graphics.fill(x1, y2 - 1, x2, y2, color);
        graphics.fill(x1, y1, x1 + 1, y2, color);
        graphics.fill(x2 - 1, y1, x2, y2, color);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) {
            return true;
        }
        for (Row row : lastRows) {
            if (event.x() >= row.screenX() && event.x() <= row.screenX() + row.width()
                    && event.y() >= row.screenY() && event.y() <= row.screenY() + ROW_HEIGHT - 2) {
                this.minecraft.setScreenAndShow(new ShardUsageScreen(this, repository, row.outputId()));
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        int maxScroll = Math.max(0, contentHeight - (listBottom - listTop));
        scroll = Math.max(0, Math.min(maxScroll, scroll - (int) (scrollY * (ROW_HEIGHT + ROW_GAP))));
        return true;
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
