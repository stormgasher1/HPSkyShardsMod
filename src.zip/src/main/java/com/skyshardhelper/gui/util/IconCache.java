package com.skyshardhelper.gui.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;

// Caches downloaded shard icons on disk so we don't re-fetch them every session.
// checkForUpdates() diffs the branch's latest commit SHA and only wipes the cache when it moved.
public final class IconCache {
    private static final Logger LOGGER = LoggerFactory.getLogger("skyshardhelper");
    private static final Path CACHE_DIR = FabricLoader.getInstance().getConfigDir().resolve("skyshardhelper_icon_cache");
    private static final Path META_FILE = CACHE_DIR.resolve("meta.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type META_TYPE = new TypeToken<HashMap<String, String>>() {
    }.getType();

    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    private IconCache() {
    }

    public static byte[] read(String branch, String shardId) {
        Path file = fileFor(branch, shardId);
        if (!Files.exists(file)) {
            return null;
        }
        try {
            return Files.readAllBytes(file);
        } catch (IOException e) {
            return null;
        }
    }

    public static void write(String branch, String shardId, byte[] pngBytes) {
        Path file = fileFor(branch, shardId);
        try {
            Files.createDirectories(file.getParent());
            Files.write(file, pngBytes);
        } catch (IOException e) {
            LOGGER.warn("Skyshard Helper: failed to cache icon for '{}' to disk: {}", shardId, e.getMessage());
        }
    }

    private static Path fileFor(String branch, String shardId) {
        return CACHE_DIR.resolve(branch).resolve(shardId.toLowerCase(Locale.ROOT) + ".png");
    }

    public static CompletableFuture<Void> checkForUpdates(String branch) {
        String url = "https://api.github.com/repos/Campionnn/SkyShards/git/refs/heads/" + branch;
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(8))
                .header("Accept", "application/vnd.github+json")
                .GET()
                .build();
        return CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> {
                    if (response.statusCode() != 200) {
                        LOGGER.warn("Skyshard Helper: icon cache update check for '{}' returned HTTP {}", branch, response.statusCode());
                        return;
                    }
                    onRefResponse(branch, response.body());
                })
                .exceptionally(ex -> {
                    LOGGER.warn("Skyshard Helper: icon cache update check for '{}' failed: {}", branch, ex.getMessage());
                    return null;
                });
    }

    private static void onRefResponse(String branch, String body) {
        try {
            JsonObject root = GSON.fromJson(body, JsonObject.class);
            String sha = root.getAsJsonObject("object").get("sha").getAsString();
            Map<String, String> meta = loadMeta();
            if (sha.equals(meta.get(branch))) {
                return;
            }
            clearBranch(branch);
            meta.put(branch, sha);
            saveMeta(meta);
            LOGGER.info("Skyshard Helper: '{}' branch changed on GitHub, icon cache cleared for it", branch);
        } catch (RuntimeException e) {
            LOGGER.warn("Skyshard Helper: failed to parse icon cache update check response: {}", e.getMessage());
        }
    }

    private static void clearBranch(String branch) {
        Path dir = CACHE_DIR.resolve(branch);
        if (!Files.isDirectory(dir)) {
            return;
        }
        try (Stream<Path> files = Files.list(dir)) {
            files.forEach(file -> {
                try {
                    Files.delete(file);
                } catch (IOException ignored) {
                    // best effort, a stray leftover file just means one icon lags a session behind
                }
            });
        } catch (IOException e) {
            LOGGER.warn("Skyshard Helper: failed to clear icon cache for '{}': {}", branch, e.getMessage());
        }
    }

    private static Map<String, String> loadMeta() {
        if (!Files.exists(META_FILE)) {
            return new HashMap<>();
        }
        try (Reader reader = Files.newBufferedReader(META_FILE, StandardCharsets.UTF_8)) {
            Map<String, String> loaded = GSON.fromJson(reader, META_TYPE);
            return loaded != null ? loaded : new HashMap<>();
        } catch (IOException e) {
            return new HashMap<>();
        }
    }

    private static void saveMeta(Map<String, String> meta) {
        try {
            Files.createDirectories(CACHE_DIR);
            try (Writer writer = Files.newBufferedWriter(META_FILE, StandardCharsets.UTF_8)) {
                GSON.toJson(meta, META_TYPE, writer);
            }
        } catch (IOException e) {
            LOGGER.warn("Skyshard Helper: failed to save icon cache metadata: {}", e.getMessage());
        }
    }
}
