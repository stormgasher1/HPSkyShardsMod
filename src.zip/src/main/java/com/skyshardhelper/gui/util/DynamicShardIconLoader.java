package com.skyshardhelper.gui.util;

import com.mojang.blaze3d.platform.NativeImage;
import com.skyshardhelper.SkyshardHelperClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Deque;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

// Fetches icons at runtime for shard ids that aren't bundled with this mod version and registers
// them as dynamic textures.
public final class DynamicShardIconLoader {
    private static final Logger LOGGER = LoggerFactory.getLogger("skyshardhelper");
    private static final String ICON_BASE_URL_MASTER = "https://raw.githubusercontent.com/Campionnn/SkyShards/master/public/shardIcons/";
    private static final String ICON_BASE_URL_DEV = "https://raw.githubusercontent.com/Campionnn/SkyShards/dev/public/shardIcons/";

    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    private static final Set<String> REQUESTED = ConcurrentHashMap.newKeySet();
    private static final Map<String, int[]> REGISTERED_SIZE = new ConcurrentHashMap<>();

    // dev mode can queue 100+ icons at once, no point hammering a flaky host with all of them
    private static final int MAX_CONCURRENT_FETCHES = 4;
    private static final Deque<String> PENDING = new ConcurrentLinkedDeque<>();
    private static final AtomicInteger IN_FLIGHT = new AtomicInteger(0);

    private DynamicShardIconLoader() {
    }

    public static boolean isRegistered(String shardId) {
        return REGISTERED_SIZE.containsKey(shardId);
    }

    // {width, height}, only valid once isRegistered() is true
    public static int[] sizeOf(String shardId) {
        return REGISTERED_SIZE.get(shardId);
    }

    public static Identifier textureId(String shardId) {
        return Identifier.fromNamespaceAndPath(SkyshardHelperClient.MOD_ID,
                "dynamic_shard_icon/" + shardId.toLowerCase(Locale.ROOT));
    }

    // wipes what's fetched/registered so far - used when devVersionEnabled toggles and icons need
    // to come from the other branch instead
    public static void clearCache() {
        REQUESTED.clear();
        REGISTERED_SIZE.clear();
        PENDING.clear();
    }

    private static final int MAX_ATTEMPTS = 3;
    private static final long RETRY_DELAY_MILLIS = 400;

    public static void requestIfMissing(String shardId) {
        if (isRegistered(shardId) || !REQUESTED.add(shardId)) {
            return;
        }
        byte[] cached = IconCache.read(currentBranch(), shardId);
        if (cached != null) {
            register(shardId, cached);
            return;
        }
        PENDING.addLast(shardId);
        pumpQueue();
    }

    private static String currentBranch() {
        return SkyshardHelperClient.CONFIG.devVersionEnabled ? "dev" : "master";
    }

    // CAS loop - runs from both the render thread and HTTP callback threads
    private static void pumpQueue() {
        while (true) {
            int current = IN_FLIGHT.get();
            if (current >= MAX_CONCURRENT_FETCHES) {
                return;
            }
            String shardId = PENDING.pollFirst();
            if (shardId == null) {
                return;
            }
            if (!IN_FLIGHT.compareAndSet(current, current + 1)) {
                PENDING.addFirst(shardId);
                continue;
            }
            startFetch(shardId);
        }
    }

    private static void startFetch(String shardId) {
        String branch = currentBranch();
        String base = branch.equals("dev") ? ICON_BASE_URL_DEV : ICON_BASE_URL_MASTER;
        String url = base + shardId + ".png";
        fetch(url, MAX_ATTEMPTS)
                .thenAccept(response -> {
                    if (response.statusCode() != 200) {
                        LOGGER.warn("Skyshard Helper: no icon found for shard '{}' (HTTP {})", shardId, response.statusCode());
                        return;
                    }
                    IconCache.write(branch, shardId, response.body());
                    register(shardId, response.body());
                })
                .exceptionally(ex -> {
                    LOGGER.warn("Skyshard Helper: failed to fetch icon for shard '{}': {}", shardId, ex.getMessage());
                    return null;
                })
                .whenComplete((ignoredResult, ignoredEx) -> {
                    IN_FLIGHT.decrementAndGet();
                    pumpQueue();
                });
    }

    private static CompletableFuture<HttpResponse<byte[]>> fetch(String url, int attemptsLeft) {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(8))
                .GET()
                .build();
        return CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofByteArray())
                .handle((response, ex) -> {
                    if (ex == null) {
                        return CompletableFuture.completedFuture(response);
                    }
                    if (attemptsLeft <= 1) {
                        CompletableFuture<HttpResponse<byte[]>> failed = new CompletableFuture<>();
                        failed.completeExceptionally(ex);
                        return failed;
                    }
                    return CompletableFuture.supplyAsync(() -> (HttpResponse<byte[]>) null,
                                    CompletableFuture.delayedExecutor(RETRY_DELAY_MILLIS, TimeUnit.MILLISECONDS))
                            .thenCompose(ignored -> fetch(url, attemptsLeft - 1));
                })
                .thenCompose(future -> future);
    }

    // texture upload needs the GL context, so hop back onto the render thread
    private static void register(String shardId, byte[] pngBytes) {
        Minecraft.getInstance().execute(() -> {
            try {
                NativeImage image = NativeImage.read(pngBytes);
                DynamicTexture texture = new DynamicTexture(() -> "skyshardhelper dynamic icon " + shardId, image);
                Minecraft.getInstance().getTextureManager().register(textureId(shardId), texture);
                REGISTERED_SIZE.put(shardId, new int[]{image.getWidth(), image.getHeight()});
                LOGGER.info("Skyshard Helper: fetched and registered icon for new shard '{}'", shardId);
            } catch (Exception e) {
                LOGGER.warn("Skyshard Helper: failed to decode icon for shard '{}': {}", shardId, e.getMessage());
            }
        });
    }
}
