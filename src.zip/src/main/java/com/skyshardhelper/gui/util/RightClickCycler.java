package com.skyshardhelper.gui.util;

import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import org.lwjgl.glfw.GLFW;

// Right click on a CycleButton (rarity/category filters, Kuudra tier, ...) cycles it backward.
// Vanilla only does that on Shift+Click, so we just fake a shift-click and let onPress handle it.
public final class RightClickCycler {
    private RightClickCycler() {
    }

    // call from a screen's mouseClicked; returns true if the click got consumed
    public static boolean tryReverse(Screen screen, MouseButtonEvent event) {
        if (event.button() != 1) {
            return false;
        }
        for (var child : screen.children()) {
            if (child instanceof CycleButton<?> button && button.isActive() && button.isMouseOver(event.x(), event.y())) {
                MouseButtonInfo shiftHeld = new MouseButtonInfo(event.button(), event.modifiers() | GLFW.GLFW_MOD_SHIFT);
                button.onPress(new MouseButtonEvent(event.x(), event.y(), shiftHeld));
                return true;
            }
        }
        return false;
    }
}
