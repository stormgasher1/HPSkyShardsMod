package com.skyshardhelper.gui.util;

import com.skyshardhelper.SkyshardHelperClient;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

// Shard id -> icon texture. Falls back to DynamicShardIconLoader for shards with no bundled texture.
public final class ShardIcons {
    // native PNG size, not square
    private static final int NATIVE_WIDTH = 190;
    private static final int NATIVE_HEIGHT = 191;

    private static final Map<String, Boolean> BUNDLED_CACHE = new ConcurrentHashMap<>();

    private ShardIcons() {
    }

    public static Identifier id(String shardId) {
        return Identifier.fromNamespaceAndPath(SkyshardHelperClient.MOD_ID,
                "textures/shard/" + shardId.toLowerCase(Locale.ROOT) + ".png");
    }

    public static void draw(GuiGraphicsExtractor graphics, String shardId, int x, int y, int size) {
        if (DynamicShardIconLoader.isRegistered(shardId)) {
            int[] dims = DynamicShardIconLoader.sizeOf(shardId);
            graphics.blit(RenderPipelines.GUI_TEXTURED, DynamicShardIconLoader.textureId(shardId), x, y, 0f, 0f,
                    size, size, dims[0], dims[1], dims[0], dims[1]);
            return;
        }
        if (!isBundled(shardId)) {
            DynamicShardIconLoader.requestIfMissing(shardId);
        }
        // blit(pipeline, texture, x, y, u, v, destWidth, destHeight, regionWidth, regionHeight, textureWidth, textureHeight)
        graphics.blit(RenderPipelines.GUI_TEXTURED, id(shardId), x, y, 0f, 0f,
                size, size, NATIVE_WIDTH, NATIVE_HEIGHT, NATIVE_WIDTH, NATIVE_HEIGHT);
    }

    private static boolean isBundled(String shardId) {
        return BUNDLED_CACHE.computeIfAbsent(shardId,
                id -> ShardIcons.class.getResource("/assets/" + SkyshardHelperClient.MOD_ID + "/textures/shard/"
                        + id.toLowerCase(Locale.ROOT) + ".png") != null);
    }
}
