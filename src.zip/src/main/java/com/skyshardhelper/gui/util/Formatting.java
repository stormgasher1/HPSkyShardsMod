package com.skyshardhelper.gui.util;

import java.util.Locale;

/** Ports of skyshards.com's {@code formatTime}/{@code formatNumber} (src/utilities/utilityFunctions.ts). */
public final class Formatting {
    private Formatting() {
    }

    public static String formatTime(double hours) {
        if (hours * 3600 < 60) {
            long seconds = Math.round(hours * 3600);
            return seconds + " sec";
        }
        long totalMinutes = Math.round(hours * 60);
        long h = totalMinutes / 60;
        long m = totalMinutes % 60;
        if (h == 0) {
            return m + " min";
        }
        if (m == 0) {
            return h + " hr";
        }
        return h + " hr " + m + " min";
    }

    public static String formatNumber(double num) {
        if (num == 0) {
            return "0";
        }
        double abs = Math.abs(num);
        if (abs < 0.01) {
            return String.format(Locale.ROOT, "%.4f", num);
        }
        if (abs < 1) {
            return String.format(Locale.ROOT, "%.2f", num);
        }
        if (abs >= 1_000_000_000) {
            return abbreviate(num, 1_000_000_000.0, "B");
        }
        if (abs >= 1_000_000) {
            return abbreviate(num, 1_000_000.0, "M");
        }
        if (abs >= 1000) {
            return abbreviate(num, 1000.0, "k");
        }
        String s = String.format(Locale.ROOT, "%.2f", num);
        if (s.endsWith(".00")) {
            s = s.substring(0, s.length() - 3);
        }
        return s;
    }

    private static String abbreviate(double num, double unit, String suffix) {
        String s = String.format(Locale.ROOT, "%.1f", num / unit);
        if (s.endsWith(".0")) {
            s = s.substring(0, s.length() - 2);
        }
        return s + suffix;
    }
}
