package com.skyshardhelper.gui;

import com.skyshardhelper.SkyshardHelperClient;
import com.skyshardhelper.config.SkyshardConfig;
import com.skyshardhelper.data.KnownShardsStore;
import com.skyshardhelper.data.Shard;
import com.skyshardhelper.gui.util.Formatting;
import com.skyshardhelper.gui.util.RightClickCycler;
import com.skyshardhelper.gui.util.ShardIcons;
import com.skyshardhelper.service.ShardRepository;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ARGB;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

// Full-catalog shard browser with rarity/category filters, opened from the calculator's search box.
public final class ShardBrowserScreen extends Screen {
    private static final int PADDING = 8;
    private static final int ROW_H = 20;
    private static final int ICON_SIZE = 16;
    private static final int CARD_BG = ARGB.color(200, 30, 30, 40);
    private static final int ROW_BG = ARGB.color(230, 40, 40, 52);
    private static final int TEXT = ARGB.opaque(0xE0E0E0);
    private static final int MUTED = ARGB.opaque(0x9A9CA8);
    private static final int MISSING = ARGB.opaque(0xE0A05A);

    private static final int GRID_CELL_SIZE = 40;
    private static final int GRID_ICON_SIZE = 28;
    private static final int GRID_GAP = 4;

    private static final List<String> RARITIES = List.of("all", "common", "uncommon", "rare", "epic", "legendary");
    // dev-shard filter, only shown when devVersionEnabled is on
    private static final String DEV_CATEGORY = "__dev__";

    private final Screen parent;
    private final ShardRepository repository;
    private final KnownShardsStore knownShards;
    private final Consumer<Shard> onSelect;
    private final List<String> categories;
    private final boolean missingFeatureEnabled;
    private final boolean iconGridMode;
    private final boolean devVersionEnabled;
    private final boolean showBazaarPrice;
    private final boolean ironManView;

    private EditBox searchBox;
    private String searchQuery = "";
    private String rarity;
    private String category;
    private boolean missingOnly;

    private int listTop;
    private int listBottom;
    private int scroll;
    private int contentHeight;
    private List<Shard> filtered = List.of();

    private int gridColumns = 1;
    private int gridCellWidth;

    private int rarityHeadingX;
    private int categoryHeadingX;
    private int missingHeadingX;

    public ShardBrowserScreen(Screen parent, ShardRepository repository, KnownShardsStore knownShards,
                               SkyshardConfig config, String initialRarity, String initialCategory,
                               Consumer<Shard> onSelect) {
        super(Component.translatable("screen.skyshardhelper.browse_shards.title"));
        this.parent = parent;
        this.repository = repository;
        this.knownShards = knownShards;
        this.onSelect = onSelect;
        this.missingFeatureEnabled = config.missingShardsFeatureEnabled;
        this.iconGridMode = config.browseIconGridMode;
        this.devVersionEnabled = config.devVersionEnabled;
        this.showBazaarPrice = config.showBazaarPriceInTooltip;
        this.ironManView = config.ironManView;
        this.rarity = initialRarity == null ? "all" : initialRarity;
        this.category = initialCategory == null ? "all" : initialCategory;

        this.categories = new ArrayList<>();
        this.categories.add("all");
        repository.all().stream().map(Shard::type).filter(t -> t != null && !t.isBlank()).distinct().sorted()
                .forEach(categories::add);
        if (devVersionEnabled) {
            this.categories.add(DEV_CATEGORY);
        }
    }

    @Override
    protected void init() {
        listTop = 56;
        listBottom = this.height - 32;

        int filterWidth = 90;
        int filterCount = missingFeatureEnabled ? 3 : 2;
        int searchWidth = this.width - 2 * PADDING - filterCount * filterWidth - filterCount * 4;
        int rarityX = PADDING + searchWidth + 4;
        int categoryX = rarityX + filterWidth + 4;
        int missingX = categoryX + filterWidth + 4;

        searchBox = new EditBox(this.font, PADDING, PADDING + 16, searchWidth, ROW_H,
                Component.translatable("screen.skyshardhelper.search"));
        searchBox.setHint(Component.translatable("screen.skyshardhelper.search"));
        searchBox.setValue(searchQuery);
        searchBox.setResponder(text -> {
            searchQuery = text;
            refresh();
        });
        this.addRenderableWidget(searchBox);

        rarityHeadingX = rarityX;
        categoryHeadingX = categoryX;

        this.addRenderableWidget(CycleButton.builder((String r) -> Component.literal(capitalize(r)), rarity)
                .withValues(RARITIES)
                .displayOnlyValue()
                .create(rarityX, PADDING + 16, filterWidth, ROW_H,
                        Component.translatable("screen.skyshardhelper.rarity_filter"),
                        (btn, value) -> {
                            rarity = value;
                            refresh();
                        }));

        this.addRenderableWidget(CycleButton.builder((String c) -> c.equals(DEV_CATEGORY)
                                ? Component.translatable("screen.skyshardhelper.category_dev")
                                : Component.literal(capitalize(c)), category)
                .withValues(categories)
                .displayOnlyValue()
                .create(categoryX, PADDING + 16, filterWidth, ROW_H,
                        Component.translatable("screen.skyshardhelper.category_filter"),
                        (btn, value) -> {
                            category = value;
                            refresh();
                        }));

        if (missingFeatureEnabled) {
            missingHeadingX = missingX;
            this.addRenderableWidget(CycleButton.booleanBuilder(
                            Component.translatable("screen.skyshardhelper.missing_only"),
                            Component.translatable("screen.skyshardhelper.all_shards"), missingOnly)
                    .displayOnlyValue()
                    .create(missingX, PADDING + 16, filterWidth, ROW_H,
                            Component.translatable("screen.skyshardhelper.missing_filter"),
                            (btn, value) -> {
                                missingOnly = value;
                                refresh();
                            }));
        }

        this.addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> onClose())
                .bounds(this.width - PADDING - 80, this.height - 24, 80, 20).build());

        refresh();
    }

    private void refresh() {
        List<Shard> matches = searchQuery.isBlank() ? List.copyOf(repository.all()) : repository.search(searchQuery);
        filtered = matches.stream()
                .filter(s -> rarity.equals("all") || rarity.equalsIgnoreCase(s.rarity()))
                .filter(s -> category.equals("all")
                        || (category.equals(DEV_CATEGORY) ? repository.isDevShard(s.id()) : category.equalsIgnoreCase(s.type())))
                .filter(s -> !missingFeatureEnabled || !missingOnly || !knownShards.isKnown(s.id()))
                .sorted((a, b) -> a.name().compareToIgnoreCase(b.name()))
                .toList();

        if (iconGridMode) {
            int availWidth = this.width - 2 * PADDING;
            int cell = GRID_CELL_SIZE + GRID_GAP;
            gridColumns = Math.max(1, (availWidth + GRID_GAP) / cell);
            gridCellWidth = (availWidth - (gridColumns - 1) * GRID_GAP) / gridColumns;
            int rows = (filtered.size() + gridColumns - 1) / gridColumns;
            contentHeight = rows * (GRID_CELL_SIZE + GRID_GAP);
        } else {
            contentHeight = filtered.size() * ROW_H;
        }
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentHeight - (listBottom - listTop))));
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        graphics.centeredText(this.font, this.title, this.width / 2, 8, 0xFFFFFF);
        graphics.text(this.font, filtered.size() + " shards", PADDING, listTop - 9, MUTED);

        graphics.text(this.font, Component.translatable("screen.skyshardhelper.rarity_filter").getString(),
                rarityHeadingX, PADDING + 4, MUTED);
        graphics.text(this.font, Component.translatable("screen.skyshardhelper.category_filter").getString(),
                categoryHeadingX, PADDING + 4, MUTED);
        if (missingFeatureEnabled) {
            graphics.text(this.font, Component.translatable("screen.skyshardhelper.missing_filter").getString(),
                    missingHeadingX, PADDING + 4, MUTED);
        }

        Shard hoveredShard = iconGridMode ? renderGrid(graphics, mouseX, mouseY) : renderList(graphics, mouseX, mouseY);

        if (hoveredShard != null) {
            List<Component> tooltip = new ArrayList<>();
            tooltip.add(Component.literal(hoveredShard.name()).withStyle(s -> s.withColor(hoveredShard.rarityColor())));
            tooltip.add(Component.literal(capitalize(hoveredShard.rarity()) + " · " + hoveredShard.type())
                    .withStyle(ChatFormatting.GRAY));
            repository.findPerk(hoveredShard.id()).ifPresent(perk -> {
                tooltip.add(Component.literal(perk.title()).withStyle(ChatFormatting.YELLOW));
                tooltip.add(Component.literal(perk.description()));
            });
            // Ironmen can't use the Bazaar and we don't track NPC prices yet, so just leave it off
            if (showBazaarPrice && !ironManView) {
                double sellPrice = SkyshardHelperClient.BAZAAR_PRICES.sellPriceFor(hoveredShard.internalId());
                if (sellPrice > 0) {
                    tooltip.add(Component.literal("Bazaar sell: " + Formatting.formatNumber(sellPrice) + " coins")
                            .withStyle(ChatFormatting.GOLD));
                }
            }
            graphics.setComponentTooltipForNextFrame(this.font, tooltip, mouseX, mouseY);
        }

        if (filtered.isEmpty()) {
            graphics.text(this.font, "No shards match this filter.", PADDING, listTop + 4, TEXT);
        }
    }

    private Shard renderList(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        graphics.enableScissor(PADDING, listTop, this.width - PADDING, listBottom);
        int y = listTop - scroll;
        Shard hoveredShard = null;
        for (Shard shard : filtered) {
            if (y + ROW_H >= listTop && y <= listBottom) {
                boolean hovered = mouseX >= PADDING && mouseX <= this.width - PADDING && mouseY >= y && mouseY <= y + ROW_H - 2;
                if (hovered) {
                    hoveredShard = shard;
                }
                boolean missing = missingFeatureEnabled && !knownShards.isKnown(shard.id());
                graphics.fill(PADDING, y, this.width - PADDING, y + ROW_H - 2, hovered ? ROW_BG : CARD_BG);
                ShardIcons.draw(graphics, shard.id(), PADDING + 4, y + 1, ICON_SIZE);
                graphics.text(this.font, shard.name(), PADDING + 4 + ICON_SIZE + 5, y + 5, ARGB.opaque(shard.rarityColor()));
                String meta = (missing ? "Missing · " : "") + capitalize(shard.rarity()) + " · " + shard.type();
                graphics.text(this.font, meta, this.width - PADDING - this.font.width(meta) - 4, y + 5,
                        missing ? MISSING : MUTED);
            }
            y += ROW_H;
        }
        graphics.disableScissor();
        return hoveredShard;
    }

    private Shard renderGrid(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        graphics.enableScissor(PADDING, listTop, this.width - PADDING, listBottom);
        Shard hoveredShard = null;
        for (int i = 0; i < filtered.size(); i++) {
            Shard shard = filtered.get(i);
            int col = i % gridColumns;
            int row = i / gridColumns;
            int cx = PADDING + col * (gridCellWidth + GRID_GAP);
            int cy = listTop - scroll + row * (GRID_CELL_SIZE + GRID_GAP);
            if (cy + GRID_CELL_SIZE >= listTop && cy <= listBottom) {
                boolean hovered = mouseX >= cx && mouseX <= cx + gridCellWidth && mouseY >= cy && mouseY <= cy + GRID_CELL_SIZE;
                if (hovered) {
                    hoveredShard = shard;
                }
                boolean missing = missingFeatureEnabled && !knownShards.isKnown(shard.id());
                int borderColor = missing ? MISSING : ARGB.opaque(shard.rarityColor());
                graphics.fill(cx, cy, cx + gridCellWidth, cy + GRID_CELL_SIZE, hovered ? ROW_BG : CARD_BG);
                outline(graphics, cx, cy, cx + gridCellWidth, cy + GRID_CELL_SIZE, borderColor);
                int iconX = cx + (gridCellWidth - GRID_ICON_SIZE) / 2;
                int iconY = cy + (GRID_CELL_SIZE - GRID_ICON_SIZE) / 2;
                ShardIcons.draw(graphics, shard.id(), iconX, iconY, GRID_ICON_SIZE);
            }
        }
        graphics.disableScissor();
        return hoveredShard;
    }

    private void outline(GuiGraphicsExtractor graphics, int x1, int y1, int x2, int y2, int color) {
        graphics.fill(x1, y1, x2, y1 + 1, color);
        graphics.fill(x1, y2 - 1, x2, y2, color);
        graphics.fill(x1, y1, x1 + 1, y2, color);
        graphics.fill(x2 - 1, y1, x2, y2, color);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (RightClickCycler.tryReverse(this, event)) {
            return true;
        }
        if (super.mouseClicked(event, doubleClick)) {
            return true;
        }
        if (event.y() < listTop || event.y() > listBottom || event.x() < PADDING || event.x() > this.width - PADDING) {
            return false;
        }
        int index = iconGridMode ? gridIndexAt(event.x(), event.y()) : (int) ((event.y() - listTop + scroll) / ROW_H);
        if (index < 0 || index >= filtered.size()) {
            return false;
        }
        Shard shard = filtered.get(index);
        if (event.button() == 1) {
            this.minecraft.setScreenAndShow(new ShardUsageScreen(this, repository, shard.id()));
            return true;
        }
        onSelect.accept(shard);
        onClose();
        return true;
    }

    private int gridIndexAt(double mouseX, double mouseY) {
        int col = (int) ((mouseX - PADDING) / (gridCellWidth + GRID_GAP));
        int row = (int) ((mouseY - (listTop - scroll)) / (GRID_CELL_SIZE + GRID_GAP));
        if (col < 0 || col >= gridColumns || row < 0) {
            return -1;
        }
        double cellLocalX = mouseX - (PADDING + col * (gridCellWidth + GRID_GAP));
        if (cellLocalX > gridCellWidth) {
            return -1;
        }
        double cellLocalY = mouseY - (listTop - scroll) - row * (GRID_CELL_SIZE + GRID_GAP);
        if (cellLocalY > GRID_CELL_SIZE) {
            return -1;
        }
        return row * gridColumns + col;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        int lineHeight = iconGridMode ? GRID_CELL_SIZE + GRID_GAP : ROW_H;
        int maxScroll = Math.max(0, contentHeight - (listBottom - listTop));
        scroll = Math.max(0, Math.min(maxScroll, scroll - (int) (scrollY * lineHeight)));
        return true;
    }

    @Override
    public void onClose() {
        this.minecraft.setScreenAndShow(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) {
            return s;
        }
        return s.substring(0, 1).toUpperCase(Locale.ROOT) + s.substring(1);
    }
}
