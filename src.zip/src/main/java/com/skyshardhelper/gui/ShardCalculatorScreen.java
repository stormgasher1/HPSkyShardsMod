package com.skyshardhelper.gui;

import com.skyshardhelper.calc.CalculationParams;
import com.skyshardhelper.calc.FusionCalculator;
import com.skyshardhelper.calc.FusionNode;
import com.skyshardhelper.calc.FusionResult;
import com.skyshardhelper.config.SkyshardConfig;
import com.skyshardhelper.config.SkyshardConfigScreenFactory;
import com.skyshardhelper.data.InventoryStore;
import com.skyshardhelper.data.KnownShardsStore;
import com.skyshardhelper.data.Shard;
import com.skyshardhelper.gui.util.Formatting;
import com.skyshardhelper.gui.util.RightClickCycler;
import com.skyshardhelper.gui.util.ShardIcons;
import com.skyshardhelper.hud.HudPositionScreen;
import com.skyshardhelper.service.ShardRepository;
import com.skyshardhelper.tracking.ShardGoalTracker;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ARGB;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

// K-menu dashboard: settings sidebar plus stat tiles/Materials Needed/Fusion Tree.
public final class ShardCalculatorScreen extends Screen {
    private static final int SIDEBAR_WIDTH = 210;
    private static final int PADDING = 8;
    private static final int ICON_SIZE = 16;

    private static final int PANEL_BG = ARGB.color(210, 18, 19, 26);
    private static final int CARD_BG = ARGB.color(230, 28, 29, 38);
    private static final int ROW_BG = ARGB.color(235, 38, 39, 50);
    private static final int BORDER = ARGB.color(255, 55, 57, 72);
    private static final int TEXT = ARGB.opaque(0xEDEDED);
    private static final int MUTED = ARGB.opaque(0x9A9CA8);
    private static final int ACCENT = ARGB.opaque(0x6FB7FF);
    private static final int GOOD = ARGB.opaque(0x6BE07A);

    private final ShardRepository repository;
    private final SkyshardConfig config;
    private final InventoryStore inventory;
    private final KnownShardsStore knownShards;
    private final ShardGoalTracker tracker;
    private final FusionCalculator calculator;

    // recomputed from config.compactMode in init() so the ModMenu toggle applies next screen open
    private int rowH;
    private int toggleRowH;
    private int gap;
    private int sectionGap;

    private Shard targetShard;
    private int quantity = 1;
    private FusionResult result;

    private String searchQuery = "";
    private List<Shard> suggestions = List.of();
    private boolean suggestionsVisible;
    private boolean shardLevelsCollapsed = true;

    // expanded tree node ids, everything else renders collapsed - starts with just the root
    private final Set<String> expandedNodes = new HashSet<>(Set.of("root"));
    private int sidebarScroll;
    private int sidebarContentHeight;
    private int treeScroll;

    private EditBox searchBox;
    private EditBox quantityBox;
    private Button modsButton;
    private Button hudPositionButton;

    private int sidebarTop;
    private int sidebarBottom;
    private final List<PositionedWidget> sidebarWidgets = new ArrayList<>();
    private final List<PositionedLabel> sidebarLabels = new ArrayList<>();

    private int treeTop;
    private int treeBottom;
    private int treeContentHeight;
    private final List<TreeRowHit> lastTreeRowHits = new ArrayList<>();

    // set during Materials/Fusion Tree rendering if the mouse is over a row this frame, read at the end of extractRenderState
    private String hoveredPerkShardId;

    private record PositionedWidget(AbstractWidget widget, int baseY) {
    }

    private record PositionedLabel(String text, int x, int baseY, int color) {
    }

    private record TreeRowHit(int screenX, int screenY, int width, int height, String nodeId) {
    }

    public ShardCalculatorScreen(ShardRepository repository, SkyshardConfig config, InventoryStore inventory,
                                  KnownShardsStore knownShards, ShardGoalTracker tracker) {
        super(Component.translatable("screen.skyshardhelper.calculator.title"));
        this.repository = repository;
        this.config = config;
        this.inventory = inventory;
        this.knownShards = knownShards;
        this.tracker = tracker;
        this.calculator = new FusionCalculator(repository);

        if (tracker.isComplete()) {
            tracker.reset();
        }

        this.targetShard = tracker.selectedShard();
        this.quantity = tracker.targetAmount() > 0 ? tracker.targetAmount() : 1;
        if (targetShard != null) {
            this.searchQuery = targetShard.name();
        }
    }

    @Override
    protected void init() {
        rowH = config.compactMode ? 15 : 20;
        toggleRowH = config.compactMode ? 12 : 16;
        gap = config.compactMode ? 2 : 4;
        sectionGap = config.compactMode ? 5 : 8;

        sidebarWidgets.clear();
        sidebarLabels.clear();
        sidebarTop = PADDING + 16;
        sidebarBottom = this.height - PADDING;
        treeTop = 0;
        treeBottom = this.height - PADDING;

        buildSidebar();
        repositionSidebar();
        recompute();
    }

    // ---------------------------------------------------------------- sidebar

    private int cursorY;

    private void buildSidebar() {
        cursorY = sidebarTop + gap;
        int x = PADDING;
        int w = SIDEBAR_WIDTH;
        int half = (w - gap) / 2;

        addToggleRow("screen.skyshardhelper.use_inventory", config.useInventory, v -> {
            config.useInventory = v;
            saveConfig();
            recompute();
        });
        addToggleRow("screen.skyshardhelper.auto_save", config.autoSaveEnabled, v -> config.autoSaveEnabled = v);

        cursorY += sectionGap;
        sectionHeader("screen.skyshardhelper.target_shard");
        searchBox = new EditBox(this.font, x, 0, w, rowH, Component.translatable("screen.skyshardhelper.search"));
        searchBox.setHint(Component.translatable("screen.skyshardhelper.search"));
        searchBox.setValue(searchQuery);
        searchBox.setResponder(query -> {
            searchQuery = query;
            updateSuggestions();
        });
        addSidebar(searchBox);

        addSidebar(Button.builder(Component.translatable("screen.skyshardhelper.browse_shards"), b ->
                        this.minecraft.setScreenAndShow(new ShardBrowserScreen(this, repository, knownShards, config, "all", "all",
                                this::selectShard)))
                .bounds(x, 0, w, toggleRowH).build(), false, toggleRowH);

        addSidebarLabel("screen.skyshardhelper.amount", x);
        cursorY += 11;
        int qtyWidth = 80;
        int maxWidth = w - qtyWidth - gap;
        quantityBox = new EditBox(this.font, x, 0, qtyWidth, rowH, Component.translatable("screen.skyshardhelper.amount"));
        quantityBox.setValue(String.valueOf(quantity));
        quantityBox.setResponder(this::onQuantityChanged);
        addSidebar(quantityBox);
        addSidebar(Button.builder(Component.translatable("screen.skyshardhelper.max"), b -> {
                    if (targetShard != null) {
                        quantity = maxQuantityFor(targetShard.rarity());
                        quantityBox.setValue(String.valueOf(quantity));
                        recompute();
                    }
                })
                .bounds(x + qtyWidth + gap, 0, maxWidth, rowH).build(), true);

        cursorY += sectionGap;
        sectionHeader("screen.skyshardhelper.settings");
        addSidebar(Button.builder(Component.translatable("screen.skyshardhelper.max_stats"), b -> {
                    config.applyMaxStats();
                    saveConfig();
                    rebuild();
                })
                .bounds(x, 0, half, rowH).build());
        addSidebar(Button.builder(Component.translatable("screen.skyshardhelper.reset_stats"), b -> {
                    config.applyResetStats();
                    saveConfig();
                    rebuild();
                })
                .bounds(x + half + gap, 0, half, rowH).build(), true);

        addSidebarLabel("screen.skyshardhelper.hunter_fortune", x);
        cursorY += 11;
        EditBox fortuneBox = new EditBox(this.font, x, 0, w, rowH, Component.translatable("screen.skyshardhelper.hunter_fortune"));
        fortuneBox.setValue(String.valueOf(config.hunterFortune));
        fortuneBox.setResponder(text -> {
            config.hunterFortune = parseIntOr(text, config.hunterFortune);
            saveConfig();
            recompute();
        });
        addSidebar(fortuneBox);

        cursorY += sectionGap;
        String chevron = shardLevelsCollapsed ? "▸ " : "▾ ";
        addSidebar(Button.builder(
                        Component.literal(chevron + Component.translatable("screen.skyshardhelper.shard_levels").getString()),
                        b -> {
                            shardLevelsCollapsed = !shardLevelsCollapsed;
                            rebuild();
                        })
                .bounds(x, 0, w, toggleRowH).build(), false, toggleRowH);

        if (!shardLevelsCollapsed) {
            int col = (w - gap) / 2;
            addLevelDropdown("Newt", x, col, () -> config.newtLevel, v -> config.newtLevel = v);
            addLevelDropdown("Salamander", x + col + gap, col, () -> config.salamanderLevel, v -> config.salamanderLevel = v);
            addLevelDropdown("Lizard King", x, col, () -> config.lizardKingLevel, v -> config.lizardKingLevel = v);
            addLevelDropdown("Leviathan", x + col + gap, col, () -> config.leviathanLevel, v -> config.leviathanLevel = v);
            addLevelDropdown("Python", x, col, () -> config.pythonLevel, v -> config.pythonLevel = v);
            addLevelDropdown("King Cobra", x + col + gap, col, () -> config.kingCobraLevel, v -> config.kingCobraLevel = v);
            addLevelDropdown("Sea Serpent", x, col, () -> config.seaSerpentLevel, v -> config.seaSerpentLevel = v);
            addLevelDropdown("Tiamat", x + col + gap, col, () -> config.tiamatLevel, v -> config.tiamatLevel = v);
            addLevelDropdown("Crocodile", x, col, () -> config.crocodileLevel, v -> config.crocodileLevel = v);
        }

        cursorY += sectionGap;
        addSidebar(Button.builder(Component.translatable("screen.skyshardhelper.clear_goal"), b -> tracker.reset())
                .bounds(x, 0, w, rowH).build());

        modsButton = Button.builder(Component.empty(),
                        b -> this.minecraft.setScreenAndShow(SkyshardConfigScreenFactory.build(this, config)))
                .tooltip(Tooltip.create(Component.translatable("screen.skyshardhelper.open_modmenu")))
                .bounds(x, 0, rowH, rowH).build();
        addSidebar(modsButton);
        hudPositionButton = Button.builder(Component.empty(),
                        b -> this.minecraft.setScreenAndShow(new HudPositionScreen(config)))
                .tooltip(Tooltip.create(Component.translatable("screen.skyshardhelper.open_hud_position")))
                .bounds(x + rowH + gap, 0, rowH, rowH).build();
        addSidebar(hudPositionButton, true);

        sidebarContentHeight = cursorY - sidebarTop + PADDING;
    }

    private void sectionHeader(String translationKey) {
        sidebarLabels.add(new PositionedLabel("▸ " + Component.translatable(translationKey).getString(),
                PADDING, cursorY, ACCENT));
        cursorY += 12;
    }

    private void addSidebarLabel(String translationKey, int x) {
        sidebarLabels.add(new PositionedLabel(Component.translatable(translationKey).getString(), x, cursorY, MUTED));
    }

    private void addToggleRow(String translationKey, boolean initial, Consumer<Boolean> onChange) {
        sidebarLabels.add(new PositionedLabel(Component.translatable(translationKey).getString(),
                PADDING, cursorY + 3, TEXT));
        int toggleWidth = 46;
        CycleButton<Boolean> toggle = CycleButton.booleanBuilder(Component.literal("On"), Component.literal("Off"), initial)
                .displayOnlyValue()
                .create(PADDING + SIDEBAR_WIDTH - toggleWidth, 0, toggleWidth, toggleRowH,
                        Component.translatable(translationKey), (btn, value) -> onChange.accept(value));
        addSidebar(toggle, false, toggleRowH);
    }

    private void addLevelDropdown(String label, int x, int width, IntSupplier getter, IntConsumer setter) {
        boolean secondColumn = x != PADDING;
        sidebarLabels.add(new PositionedLabel(label, x, cursorY, MUTED));
        if (!secondColumn) {
            cursorY += 11;
        }
        CycleButton<Integer> button = CycleButton.builder((Integer v) -> Component.literal("Lv " + v), getter.getAsInt())
                .withValues(10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0)
                .displayOnlyValue()
                .create(x, 0, width, toggleRowH, Component.literal(label), (btn, value) -> {
                    setter.accept(value);
                    saveConfig();
                    recompute();
                });
        addSidebar(button, secondColumn, toggleRowH);
    }

    private void addSidebar(AbstractWidget widget) {
        addSidebar(widget, false, rowH);
    }

    private void addSidebar(AbstractWidget widget, boolean sameRowAsPrevious) {
        addSidebar(widget, sameRowAsPrevious, rowH);
    }

    private void addSidebar(AbstractWidget widget, boolean sameRowAsPrevious, int rowHeight) {
        int baseY = sameRowAsPrevious ? cursorY - (rowHeight + gap) : cursorY;
        widget.setY(baseY);
        sidebarWidgets.add(new PositionedWidget(widget, baseY));
        addRenderableWidget(widget);
        if (!sameRowAsPrevious) {
            cursorY += rowHeight + gap;
        }
    }

    private void repositionSidebar() {
        for (PositionedWidget pw : sidebarWidgets) {
            int y = pw.baseY() - sidebarScroll;
            pw.widget().setY(y);
            boolean visible = y + rowH >= sidebarTop && y <= sidebarBottom;
            pw.widget().visible = visible;
            pw.widget().active = visible;
        }
    }

    private int maxSidebarScroll() {
        int visibleHeight = sidebarBottom - sidebarTop;
        return Math.max(0, sidebarContentHeight - visibleHeight);
    }

    // ------------------------------------------------------------- callbacks

    private void updateSuggestions() {
        suggestions = searchQuery.isBlank() ? List.of() : repository.search(searchQuery).stream().limit(6).toList();
        suggestionsVisible = !suggestions.isEmpty();
    }

    private void onQuantityChanged(String text) {
        quantity = Math.max(1, parseIntOr(text, quantity));
        recompute();
    }

    private void selectShard(Shard shard) {
        targetShard = shard;
        searchQuery = shard.name();
        searchBox.setValue(shard.name());
        suggestionsVisible = false;
        quantity = maxQuantityFor(shard.rarity());
        quantityBox.setValue(String.valueOf(quantity));
        expandedNodes.clear();
        expandedNodes.add("root");
        recompute();
    }

    private void rebuild() {
        this.clearWidgets();
        init();
    }

    private void saveConfig() {
        if (config.autoSaveEnabled) {
            config.save();
        }
    }

    private void recompute() {
        if (targetShard == null) {
            result = null;
            tracker.setFusionResult(null);
            return;
        }
        CalculationParams params = new CalculationParams(
                config.hunterFortune, config.excludeChameleon, config.noWoodenBait,
                config.newtLevel, config.salamanderLevel, config.lizardKingLevel, config.leviathanLevel,
                config.pythonLevel, config.kingCobraLevel, config.seaSerpentLevel, config.tiamatLevel,
                config.crocodileLevel, config.craftPenaltySeconds / 3600.0);
        Map<String, Integer> owned = config.useInventory ? inventory.asMap() : Map.of();
        result = calculator.calculate(targetShard.id(), quantity, params, owned);
        tracker.updateGoal(targetShard, quantity);
        tracker.setFusionResult(result);
    }

    private static int maxQuantityFor(String rarity) {
        return switch (rarity == null ? "" : rarity.toLowerCase(Locale.ROOT)) {
            case "common" -> 96;
            case "uncommon" -> 64;
            case "rare" -> 48;
            case "epic" -> 32;
            case "legendary" -> 24;
            default -> 24;
        };
    }

    private static int parseIntOr(String text, int fallback) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    // -------------------------------------------------------------- render

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        // sidebar background first, vanilla widgets from super.extractRenderState() draw on top
        graphics.fill(PADDING - 4, sidebarTop - 4, PADDING + SIDEBAR_WIDTH + 4, sidebarBottom, PANEL_BG);
        outline(graphics, PADDING - 4, sidebarTop - 4, PADDING + SIDEBAR_WIDTH + 4, sidebarBottom, BORDER);
        graphics.text(this.font, inventory.shardTypeCount() + " shard types in inventory", PADDING, PADDING, MUTED);

        graphics.enableScissor(PADDING - 4, sidebarTop, PADDING + SIDEBAR_WIDTH + 4, sidebarBottom);
        for (PositionedLabel label : sidebarLabels) {
            int y = label.baseY() - sidebarScroll;
            if (y >= sidebarTop - 10 && y <= sidebarBottom) {
                graphics.text(this.font, label.text(), label.x(), y, label.color());
            }
        }
        graphics.disableScissor();

        super.extractRenderState(graphics, mouseX, mouseY, partialTick);

        if (modsButton != null && modsButton.visible) {
            drawGearIcon(graphics, modsButton.getX(), modsButton.getY(), modsButton.getWidth(), modsButton.getHeight());
        }
        if (hudPositionButton != null && hudPositionButton.visible) {
            drawMoveIcon(graphics, hudPositionButton.getX(), hudPositionButton.getY(),
                    hudPositionButton.getWidth(), hudPositionButton.getHeight());
        }

        hoveredPerkShardId = null;
        int mainX = PADDING + SIDEBAR_WIDTH + PADDING + 8;
        int mainWidth = Math.max(200, this.width - mainX - PADDING);
        int y = renderSummaryTiles(graphics, mainX, PADDING, mainWidth);
        y = renderMaterialsCard(graphics, mainX, y + sectionGap + 4, mainWidth, mouseX, mouseY);
        renderFusionTreeCard(graphics, mainX, y + sectionGap + 4, mainWidth, mouseX, mouseY);

        if (suggestionsVisible && searchBox != null) {
            renderSuggestions(graphics, mouseX, mouseY);
        }

        if (config.showPerkTooltipsInCalculator && hoveredPerkShardId != null) {
            repository.findPerk(hoveredPerkShardId).ifPresent(perk -> graphics.setComponentTooltipForNextFrame(this.font,
                    List.of(Component.literal(perk.title()).withStyle(ChatFormatting.YELLOW),
                            Component.literal(perk.description())),
                    mouseX, mouseY));
        }
    }

    private void outline(GuiGraphicsExtractor graphics, int x1, int y1, int x2, int y2, int color) {
        graphics.fill(x1, y1, x2, y1 + 1, color);
        graphics.fill(x1, y2 - 1, x2, y2, color);
        graphics.fill(x1, y1, x1 + 1, y2, color);
        graphics.fill(x2 - 1, y1, x2, y2, color);
    }

    private void card(GuiGraphicsExtractor graphics, int x, int y, int width, int height) {
        graphics.fill(x, y, x + width, y + height, CARD_BG);
        outline(graphics, x, y, x + width, y + height, BORDER);
    }

    // three bars, reads better than a unicode gear at this size
    private void drawGearIcon(GuiGraphicsExtractor graphics, int x, int y, int width, int height) {
        int barWidth = width - 8;
        int barX = x + (width - barWidth) / 2;
        int barY = y + height / 2 - 4;
        graphics.fill(barX, barY, barX + barWidth, barY + 2, ACCENT);
        graphics.fill(barX, barY + 4, barX + barWidth, barY + 6, ACCENT);
        graphics.fill(barX, barY + 8, barX + barWidth, barY + 10, ACCENT);
    }

    // four corner brackets, matches the drag handles in HudPositionScreen
    private void drawMoveIcon(GuiGraphicsExtractor graphics, int x, int y, int width, int height) {
        int inset = 5;
        int armLength = 4;
        int thickness = 2;
        int left = x + inset;
        int top = y + inset;
        int right = x + width - inset;
        int bottom = y + height - inset;

        graphics.fill(left, top, left + armLength, top + thickness, ACCENT);
        graphics.fill(left, top, left + thickness, top + armLength, ACCENT);

        graphics.fill(right - armLength, top, right, top + thickness, ACCENT);
        graphics.fill(right - thickness, top, right, top + armLength, ACCENT);

        graphics.fill(left, bottom - thickness, left + armLength, bottom, ACCENT);
        graphics.fill(left, bottom - armLength, left + thickness, bottom, ACCENT);

        graphics.fill(right - armLength, bottom - thickness, right, bottom, ACCENT);
        graphics.fill(right - thickness, bottom - armLength, right, bottom, ACCENT);
    }

    private int renderSummaryTiles(GuiGraphicsExtractor graphics, int x, int y, int width) {
        String timePerShard = result != null ? Formatting.formatTime(result.timePerShardHours()) : "-";
        String totalTime = result != null ? Formatting.formatTime(result.totalTimeHours()) : "-";
        String shardsProduced = result != null ? String.valueOf(result.totalShardsProduced()) : "-";
        String fusions = result != null ? result.totalCrafts() + "x" : "-";

        String[] labels = {"Time per Shard", "Total Time", "Shards Produced", "Total Fusions"};
        String[] values = {timePerShard, totalTime, shardsProduced, fusions};

        int tileWidth = (width - 3 * gap) / 4;
        int tileHeight = 38;
        for (int i = 0; i < 4; i++) {
            int tx = x + i * (tileWidth + gap);
            card(graphics, tx, y, tileWidth, tileHeight);
            graphics.text(this.font, labels[i], tx + 6, y + 7, MUTED);
            graphics.text(this.font, values[i], tx + 6, y + 21, TEXT);
        }
        return y + tileHeight;
    }

    private int renderMaterialsCard(GuiGraphicsExtractor graphics, int x, int y, int width, int mouseX, int mouseY) {
        graphics.text(this.font, "▸ Materials Needed", x, y, ACCENT);
        y += 13;

        if (result == null) {
            card(graphics, x, y, width, 26);
            graphics.text(this.font, "Pick a target shard to see what you need.", x + 6, y + 9, MUTED);
            return y + 26;
        }
        if (result.totalQuantities().isEmpty()) {
            card(graphics, x, y, width, 26);
            graphics.text(this.font, "You already own enough - nothing left to craft!", x + 6, y + 9, MUTED);
            return y + 26;
        }

        List<Map.Entry<String, Integer>> entries = new ArrayList<>(result.totalQuantities().entrySet());
        entries.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

        int cols = Math.max(1, (width + gap) / 224);
        int cellWidth = (width - (cols - 1) * gap) / cols;
        int cellHeight = 30;
        int i = 0;
        for (Map.Entry<String, Integer> entry : entries) {
            int row = i / cols;
            int colIdx = i % cols;
            int cx = x + colIdx * (cellWidth + gap);
            int cy = y + row * (cellHeight + gap);
            renderMaterialCell(graphics, cx, cy, cellWidth, cellHeight, entry.getKey(), entry.getValue(), mouseX, mouseY);
            i++;
        }
        int rows = (entries.size() + cols - 1) / cols;
        return y + rows * (cellHeight + gap);
    }

    private void renderMaterialCell(GuiGraphicsExtractor graphics, int x, int y, int width, int height, String shardId,
                                     int qty, int mouseX, int mouseY) {
        card(graphics, x, y, width, height);
        Shard shard = repository.findById(shardId).orElse(null);
        String name = shard != null ? shard.name() : shardId;
        int nameColor = shard != null ? ARGB.opaque(shard.rarityColor()) : TEXT;
        ShardIcons.draw(graphics, shardId, x + 5, y + (height - ICON_SIZE) / 2, ICON_SIZE);
        graphics.text(this.font, qty + "x " + name, x + 5 + ICON_SIZE + 5, y + 5, nameColor);

        double rate = result != null ? result.effectiveRates().getOrDefault(shardId, 0.0) : 0;
        if (rate > 0) {
            graphics.text(this.font, Formatting.formatNumber(rate) + "/hr", x + 5 + ICON_SIZE + 5, y + 17, MUTED);
        }

        if (config.showPerkTooltipsInCalculator
                && mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height) {
            hoveredPerkShardId = shardId;
        }
    }

    private void renderFusionTreeCard(GuiGraphicsExtractor graphics, int x, int y, int width, int mouseX, int mouseY) {
        graphics.text(this.font, "▸ Fusion Tree", x, y, ACCENT);
        y += 13;
        treeTop = y;
        treeBottom = this.height - PADDING;

        lastTreeRowHits.clear();
        if (result == null || result.tree() == null) {
            card(graphics, x, y, width, 26);
            graphics.text(this.font, "Search a shard on the left to build its fusion tree.", x + 6, y + 9, MUTED);
            return;
        }

        graphics.enableScissor(x, treeTop, x + width, treeBottom);
        int[] cursor = {y - treeScroll};
        renderTreeNode(graphics, result.tree(), x, width, "root", 0, cursor, mouseX, mouseY);
        treeContentHeight = cursor[0] - (y - treeScroll);
        graphics.disableScissor();
    }

    private void renderTreeNode(GuiGraphicsExtractor graphics, FusionNode node, int x, int width, String nodeId,
                                 int depth, int[] cursor, int mouseX, int mouseY) {
        int rowHeight = 19;
        int indent = depth * 13;
        int rowX = x + indent;
        int rowWidth = width - indent;
        int rowY = cursor[0];

        if (rowY + rowHeight >= treeTop && rowY <= treeBottom) {
            graphics.fill(rowX, rowY, rowX + rowWidth, rowY + rowHeight - 1, ROW_BG);
            Shard shard = repository.findById(node.shardId()).orElse(null);
            String name = shard != null ? shard.name() : node.shardId();
            int nameColor = shard != null ? ARGB.opaque(shard.rarityColor()) : TEXT;

            if (node instanceof FusionNode.Direct) {
                ShardIcons.draw(graphics, node.shardId(), rowX + 4, rowY + 1, ICON_SIZE);
                graphics.text(this.font, node.quantity() + "x " + name, rowX + 4 + ICON_SIZE + 4, rowY + 5, nameColor);
                graphics.text(this.font, "Direct", rowX + rowWidth - 42, rowY + 5, GOOD);
            } else if (node instanceof FusionNode.Craft craft) {
                String chevron = expandedNodes.contains(nodeId) ? "▾" : "▸";
                graphics.text(this.font, chevron, rowX + 4, rowY + 5, ACCENT);
                ShardIcons.draw(graphics, node.shardId(), rowX + 15, rowY + 1, ICON_SIZE);
                graphics.text(this.font, node.quantity() + "x " + name, rowX + 15 + ICON_SIZE + 4, rowY + 5, nameColor);
                graphics.text(this.font, craft.craftsNeeded() + " fusions", rowX + rowWidth - 72, rowY + 5, MUTED);
                lastTreeRowHits.add(new TreeRowHit(rowX, rowY, rowWidth, rowHeight, nodeId));
            }

            if (config.showPerkTooltipsInCalculator
                    && mouseX >= rowX && mouseX <= rowX + rowWidth && mouseY >= rowY && mouseY <= rowY + rowHeight
                    && mouseY >= treeTop && mouseY <= treeBottom) {
                hoveredPerkShardId = node.shardId();
            }
        }
        cursor[0] += rowHeight + 2;

        if (node instanceof FusionNode.Craft craft && expandedNodes.contains(nodeId)) {
            renderTreeNode(graphics, craft.input1(), x, width, nodeId + "-0", depth + 1, cursor, mouseX, mouseY);
            renderTreeNode(graphics, craft.input2(), x, width, nodeId + "-1", depth + 1, cursor, mouseX, mouseY);
        }
    }

    private void renderSuggestions(GuiGraphicsExtractor graphics, int mouseX, int mouseY) {
        int x = searchBox.getX();
        int y = searchBox.getY() + rowH + 1;
        int width = searchBox.getWidth();
        int rowHeight = 16;
        card(graphics, x, y, width, suggestions.size() * rowHeight);
        for (int i = 0; i < suggestions.size(); i++) {
            Shard shard = suggestions.get(i);
            int ry = y + i * rowHeight;
            boolean hovered = mouseX >= x && mouseX <= x + width && mouseY >= ry && mouseY <= ry + rowHeight;
            if (hovered) {
                graphics.fill(x, ry, x + width, ry + rowHeight, ROW_BG);
            }
            graphics.text(this.font, shard.name(), x + 4, ry + 4, ARGB.opaque(shard.rarityColor()));
        }
    }

    // ---------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (RightClickCycler.tryReverse(this, event)) {
            return true;
        }
        if (suggestionsVisible && searchBox != null) {
            int x = searchBox.getX();
            int y = searchBox.getY() + rowH + 1;
            int width = searchBox.getWidth();
            int rowHeight = 16;
            if (event.x() >= x && event.x() <= x + width && event.y() >= y && event.y() <= y + suggestions.size() * rowHeight) {
                int index = (int) ((event.y() - y) / rowHeight);
                if (index >= 0 && index < suggestions.size()) {
                    selectShard(suggestions.get(index));
                    return true;
                }
            }
        }

        boolean handled = super.mouseClicked(event, doubleClick);
        if (handled) {
            suggestionsVisible = false;
            return true;
        }

        for (TreeRowHit hit : lastTreeRowHits) {
            if (event.x() >= hit.screenX() && event.x() <= hit.screenX() + hit.width()
                    && event.y() >= hit.screenY() && event.y() <= hit.screenY() + hit.height()) {
                if (expandedNodes.contains(hit.nodeId())) {
                    expandedNodes.remove(hit.nodeId());
                } else {
                    expandedNodes.add(hit.nodeId());
                }
                return true;
            }
        }

        suggestionsVisible = false;
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (mouseX < PADDING + SIDEBAR_WIDTH + PADDING) {
            sidebarScroll = Math.max(0, Math.min(maxSidebarScroll(), sidebarScroll - (int) (scrollY * rowH)));
            repositionSidebar();
            return true;
        }
        if (mouseY >= treeTop) {
            int maxScroll = Math.max(0, treeContentHeight - (treeBottom - treeTop));
            treeScroll = Math.max(0, Math.min(maxScroll, treeScroll - (int) (scrollY * 18)));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
