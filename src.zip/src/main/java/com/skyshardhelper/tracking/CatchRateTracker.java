package com.skyshardhelper.tracking;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.function.ToDoubleFunction;

// Rolling 3-minute window for shards/coins per hour, so it tracks current activity instead of a session-wide average.
public final class CatchRateTracker {
    private static final long WINDOW_MILLIS = 3 * 60_000L;
    // floor the divisor at 30s, otherwise a catch 10ms after the window starts reads as like 360000/hr
    private static final long MIN_ELAPSED_MILLIS = 30_000L;

    private record Event(long timestampMillis, String shardId, int quantity) {
    }

    private final Deque<Event> events = new ArrayDeque<>();
    private long totalObtained;

    public void record(String shardId, int quantity) {
        long now = System.currentTimeMillis();
        events.addLast(new Event(now, shardId, quantity));
        totalObtained += quantity;
        prune(now);
    }

    private void prune(long now) {
        while (!events.isEmpty() && now - events.peekFirst().timestampMillis() > WINDOW_MILLIS) {
            events.pollFirst();
        }
    }

    public double perHour() {
        long now = System.currentTimeMillis();
        prune(now);
        if (events.isEmpty()) {
            return 0;
        }
        double elapsedHours = Math.max(now - events.peekFirst().timestampMillis(), MIN_ELAPSED_MILLIS) / 3_600_000.0;
        int sum = 0;
        for (Event event : events) {
            sum += event.quantity();
        }
        return sum / elapsedHours;
    }

    // same window as perHour(), but priced via the given lookup; unpriced shards just contribute 0
    public double moneyPerHour(ToDoubleFunction<String> sellPriceForShardId) {
        long now = System.currentTimeMillis();
        prune(now);
        if (events.isEmpty()) {
            return 0;
        }
        double elapsedHours = Math.max(now - events.peekFirst().timestampMillis(), MIN_ELAPSED_MILLIS) / 3_600_000.0;
        double totalCoins = 0;
        for (Event event : events) {
            totalCoins += event.quantity() * sellPriceForShardId.applyAsDouble(event.shardId());
        }
        return totalCoins / elapsedHours;
    }

    public long totalObtained() {
        return totalObtained;
    }

    public void reset() {
        events.clear();
        totalObtained = 0;
    }
}
