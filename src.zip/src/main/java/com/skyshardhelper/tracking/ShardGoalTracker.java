package com.skyshardhelper.tracking;

import com.skyshardhelper.calc.FusionResult;
import com.skyshardhelper.data.Shard;

import java.util.LinkedHashMap;
import java.util.Map;

// Shared between the calculator screen, chat listener and HUD - fine since it's all client-thread.
public final class ShardGoalTracker {
    private Shard selectedShard;
    private int targetAmount;
    private int currentAmount;

    private FusionResult fusionResult;
    private final Map<String, Integer> obtainedPerLeaf = new LinkedHashMap<>();

    public void setGoal(Shard shard, int targetAmount) {
        this.selectedShard = shard;
        this.targetAmount = Math.max(targetAmount, 1);
        this.currentAmount = 0;
        this.obtainedPerLeaf.clear();
    }

    // Keeps progress if it's the same shard as before, otherwise resets like setGoal.
    public void updateGoal(Shard shard, int targetAmount) {
        boolean sameShard = selectedShard != null && shard != null && selectedShard.id().equals(shard.id());
        if (!sameShard) {
            setGoal(shard, targetAmount);
            return;
        }
        this.targetAmount = Math.max(targetAmount, 1);
    }

    public void setFusionResult(FusionResult result) {
        this.fusionResult = result;
    }

    public FusionResult fusionResult() {
        return fusionResult;
    }

    public void reset() {
        this.selectedShard = null;
        this.targetAmount = 0;
        this.currentAmount = 0;
        this.fusionResult = null;
        this.obtainedPerLeaf.clear();
    }

    public void onShardObtained(Shard shard, int quantity) {
        if (selectedShard != null && selectedShard.id().equals(shard.id())) {
            currentAmount = Math.min(targetAmount, currentAmount + quantity);
        }
        if (fusionResult != null && fusionResult.totalQuantities().containsKey(shard.id())) {
            int needed = fusionResult.totalQuantities().get(shard.id());
            int obtained = obtainedPerLeaf.getOrDefault(shard.id(), 0);
            obtainedPerLeaf.put(shard.id(), Math.min(needed, obtained + quantity));
        }
    }

    public Map<String, Integer> obtainedPerLeaf() {
        return obtainedPerLeaf;
    }

    public boolean isAllMaterialsComplete() {
        if (fusionResult == null || fusionResult.totalQuantities().isEmpty()) {
            return false;
        }
        for (Map.Entry<String, Integer> entry : fusionResult.totalQuantities().entrySet()) {
            if (obtainedPerLeaf.getOrDefault(entry.getKey(), 0) < entry.getValue()) {
                return false;
            }
        }
        return true;
    }

    public boolean isActive() {
        return selectedShard != null;
    }

    public boolean isComplete() {
        return isActive() && currentAmount >= targetAmount;
    }

    public int remaining() {
        return Math.max(0, targetAmount - currentAmount);
    }

    public Shard selectedShard() {
        return selectedShard;
    }

    public int targetAmount() {
        return targetAmount;
    }

    public int currentAmount() {
        return currentAmount;
    }
}
