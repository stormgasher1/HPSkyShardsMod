package com.skyshardhelper.integration;

import com.skyshardhelper.SkyshardHelperClient;
import com.skyshardhelper.config.SkyshardConfigScreenFactory;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

public final class SkyshardModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> SkyshardConfigScreenFactory.build(parent, SkyshardHelperClient.CONFIG);
    }
}
