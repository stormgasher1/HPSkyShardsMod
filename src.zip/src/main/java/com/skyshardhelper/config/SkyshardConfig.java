package com.skyshardhelper.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

// Gson-persisted settings. Owns its own load/save, the settings screen just reads/writes fields on it.
public final class SkyshardConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger("skyshardhelper");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String FILE_NAME = "skyshardhelper.json";

    public boolean hudEnabled = true;
    public HudCorner hudCorner = HudCorner.TOP_RIGHT;
    public int hudOffsetX = 4;
    public int hudOffsetY = 4;

    // shards/hour meter, added via the "+" button in the /sshs position editor
    public boolean rateHudEnabled = false;
    public HudCorner rateHudCorner = HudCorner.BOTTOM_LEFT;
    public int rateHudOffsetX = 4;
    public int rateHudOffsetY = 4;

    public boolean moneyHudEnabled = false; // coins/hour meter, only offered in /sshs while not on Ironman
    public HudCorner moneyHudCorner = HudCorner.BOTTOM_LEFT;
    public int moneyHudOffsetX = 4;
    public int moneyHudOffsetY = 26;

    public boolean showPerkTooltipsInCalculator = false;

    // ownership detection this depends on is a no-op right now, so keep it off by default
    public boolean missingShardsFeatureEnabled = false;

    // fetches from the "dev" branch instead of "master", so this can and will break - stays off by default.
    // volatile because the sync-scheduler thread reads it too (see SkyshardHelperClient)
    public volatile boolean devVersionEnabled = false;

    public boolean browseIconGridMode = true;
    public boolean showBazaarPriceInTooltip = true;

    // volatile: all three are read from the background sync-scheduler thread, written from the client thread.
    public volatile boolean apiSyncEnabled = true;
    public volatile String apiBaseUrl = "https://skyshards.com/";
    public volatile int syncIntervalMinutes = 30;

    // set via /sshs apikey <key>; optional, the public bazaar endpoint works fine without it
    public volatile String hypixelApiKey = null;

    // Each pattern needs a named group "(?<shard>...)"; an optional "(?<qty>...)" defaults to 1.
    // Messages arrive with legacy "§x" codes already stripped by the chat listener.
    private static final String CATCH_CHAT_PATTERN = "You caught (?:an?|x(?<qty>\\d+)) (?<shard>.+?) Shards?!";
    private static final String FUSION_CHAT_PATTERN = "FUSION! You obtained (?<shard>.+?) Shards?(?: x(?<qty>\\d+))?!";
    private static final String LOOT_SHARE_CHAT_PATTERN = "You received (?:an?|(?<qty>\\d+)) (?<shard>.+?) Shards? for assisting";

    public List<String> chatRegexPatterns = new ArrayList<>(
            List.of(CATCH_CHAT_PATTERN, FUSION_CHAT_PATTERN, LOOT_SHARE_CHAT_PATTERN));

    // Calculator settings, mirrors skyshards.com's form state.
    // ironManView gets auto-detected from the scoreboard now (IronmanScoreboardScanner), not user-editable
    // anymore. Defaults true until the scoreboard's actually been read once.
    public boolean ironManView = true;
    public boolean useInventory = false;
    public boolean autoSaveEnabled = true;
    public boolean compactMode = false;

    public int hunterFortune = 0;
    public boolean excludeChameleon = false;
    public boolean noWoodenBait = false;

    public int newtLevel = 0;
    public int salamanderLevel = 0;
    public int lizardKingLevel = 0;
    public int leviathanLevel = 0;
    public int pythonLevel = 0;
    public int kingCobraLevel = 0;
    public int seaSerpentLevel = 0;
    public int tiamatLevel = 0;
    public int crocodileLevel = 0;

    public double craftPenaltySeconds = 0.8;
    public KuudraTier kuudraTier = KuudraTier.NONE;
    public Double moneyPerHour = null;
    public boolean customKuudraTime = false;
    public Double kuudraTimeSeconds = null;

    // mirrors the website's "Max Stats" button
    public void applyMaxStats() {
        hunterFortune = 122;
        newtLevel = salamanderLevel = lizardKingLevel = leviathanLevel = pythonLevel
                = kingCobraLevel = seaSerpentLevel = tiamatLevel = crocodileLevel = 10;
        kuudraTier = KuudraTier.T5;
    }

    public void applyResetStats() { // mirrors "Reset Stats"; leaves ironManView/useInventory alone
        hunterFortune = 0;
        excludeChameleon = false;
        noWoodenBait = false;
        newtLevel = salamanderLevel = lizardKingLevel = leviathanLevel = pythonLevel
                = kingCobraLevel = seaSerpentLevel = tiamatLevel = crocodileLevel = 0;
        kuudraTier = KuudraTier.NONE;
        moneyPerHour = null;
        customKuudraTime = false;
        kuudraTimeSeconds = null;
        craftPenaltySeconds = 0.8;
    }

    // first pattern this mod ever shipped with, turned out to never actually match. see migrateChatPattern below.
    private static final List<String> OBSOLETE_CHAT_PATTERNS = List.of(
            "^You received (?<shard>.+) Shard!?$",
            "^You caught (?:an?|x(?<qty>\\d+)) (?<shard>.+) Shards?!$"
    );

    public static SkyshardConfig loadOrCreate() {
        Path path = configPath();
        if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                SkyshardConfig loaded = GSON.fromJson(reader, SkyshardConfig.class);
                if (loaded != null) {
                    loaded.migrateChatPattern();
                    loaded.addFusionPatternIfMissing();
                    loaded.addLootSharePatternIfMissing();
                    loaded.clampReptileLevels();
                    return loaded;
                }
            } catch (IOException e) {
                LOGGER.error("Skyshard Helper: failed to read config, using defaults", e);
            }
        }
        SkyshardConfig defaults = new SkyshardConfig();
        defaults.save();
        return defaults;
    }

    private void migrateChatPattern() {
        if (chatRegexPatterns != null && chatRegexPatterns.size() == 1
                && OBSOLETE_CHAT_PATTERNS.contains(chatRegexPatterns.get(0))) {
            chatRegexPatterns = new SkyshardConfig().chatRegexPatterns;
            save();
            LOGGER.info("Skyshard Helper: migrated obsolete chat pattern to the current one");
        }
    }

    private void addFusionPatternIfMissing() { // for configs saved before fusion detection existed
        if (chatRegexPatterns != null && !chatRegexPatterns.contains(FUSION_CHAT_PATTERN)) {
            chatRegexPatterns.add(FUSION_CHAT_PATTERN);
            save();
            LOGGER.info("Skyshard Helper: added fusion-completion chat pattern to existing config");
        }
    }

    private void addLootSharePatternIfMissing() { // same idea, for the later Loot Share pattern
        if (chatRegexPatterns != null && !chatRegexPatterns.contains(LOOT_SHARE_CHAT_PATTERN)) {
            chatRegexPatterns.add(LOOT_SHARE_CHAT_PATTERN);
            save();
            LOGGER.info("Skyshard Helper: added Loot Share chat pattern to existing config");
        }
    }

    // dropdowns only go 0-10, so a hand-edited config.json outside that range would hand the CycleButton
    // a value it doesn't have an entry for
    private void clampReptileLevels() {
        newtLevel = Math.clamp(newtLevel, 0, 10);
        salamanderLevel = Math.clamp(salamanderLevel, 0, 10);
        lizardKingLevel = Math.clamp(lizardKingLevel, 0, 10);
        leviathanLevel = Math.clamp(leviathanLevel, 0, 10);
        pythonLevel = Math.clamp(pythonLevel, 0, 10);
        kingCobraLevel = Math.clamp(kingCobraLevel, 0, 10);
        seaSerpentLevel = Math.clamp(seaSerpentLevel, 0, 10);
        tiamatLevel = Math.clamp(tiamatLevel, 0, 10);
        crocodileLevel = Math.clamp(crocodileLevel, 0, 10);
    }

    public void save() {
        Path path = configPath();
        try {
            Files.createDirectories(path.getParent());
            try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            LOGGER.error("Skyshard Helper: failed to save config", e);
        }
    }

    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
    }
}
