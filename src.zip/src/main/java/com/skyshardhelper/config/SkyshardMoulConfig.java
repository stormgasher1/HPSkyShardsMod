package com.skyshardhelper.config;

import com.skyshardhelper.SkyshardHelperClient;
import com.skyshardhelper.hud.HudPositionScreen;
import io.github.notenoughupdates.moulconfig.Config;
import io.github.notenoughupdates.moulconfig.annotations.Category;
import io.github.notenoughupdates.moulconfig.annotations.ConfigEditorBoolean;
import io.github.notenoughupdates.moulconfig.annotations.ConfigEditorButton;
import io.github.notenoughupdates.moulconfig.annotations.ConfigEditorDropdown;
import io.github.notenoughupdates.moulconfig.annotations.ConfigEditorInfoText;
import io.github.notenoughupdates.moulconfig.annotations.ConfigEditorSlider;
import io.github.notenoughupdates.moulconfig.annotations.ConfigEditorText;
import io.github.notenoughupdates.moulconfig.annotations.ConfigOption;
import io.github.notenoughupdates.moulconfig.common.text.StructuredText;
import io.github.notenoughupdates.moulconfig.observer.GetSetter;
import io.github.notenoughupdates.moulconfig.observer.Property;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Util;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

// mirrors SkyshardConfig for the settings screen - every field here just writes through and saves
public final class SkyshardMoulConfig extends Config {
    private static final String ISSUES_URL = "https://github.com/stormgasher1/SkyshardsMod/issues";

    @Category(name = "HUD", desc = "The on-screen shard progress overlay.")
    public HudCategory hud;

    @Category(name = "Calculator", desc = "Options for the K-menu fusion calculator.")
    public CalculatorCategory calculator;

    @Category(name = "Waypoints", desc = "Not implemented yet.")
    public WaypointsCategory waypoints;

    @Category(name = "Misc", desc = "Data sync, chat detection, dev tools and issue reporting.")
    public MiscCategory misc;

    public SkyshardMoulConfig(SkyshardConfig config) {
        this.hud = new HudCategory(config);
        this.calculator = new CalculatorCategory(config);
        this.waypoints = new WaypointsCategory();
        this.misc = new MiscCategory(config);
    }

    @Override
    public StructuredText getTitle() {
        return StructuredText.of("Skyshard Helper");
    }

    @Override
    public boolean isValidRunnable(int runnableId) {
        return false;
    }

    private static <T> Property<T> bind(Supplier<T> getter, Consumer<T> setter) {
        return Property.wrap(new GetSetter<T>() {
            @Override
            public T get() {
                return getter.get();
            }

            @Override
            public void set(T value) {
                setter.accept(value);
            }
        });
    }

    public static final class HudCategory {
        @ConfigOption(name = "Show HUD overlay", desc = "Toggles the on-screen shard progress overlay.")
        @ConfigEditorBoolean
        public Property<Boolean> hudEnabled;

        @ConfigOption(name = "HUD corner", desc = "Which screen corner the overlay is anchored to.")
        @ConfigEditorDropdown
        public Property<HudCorner> hudCorner;

        @ConfigOption(name = "Show Shards/Hour panel",
                desc = "Toggles the small shards-obtained-per-hour meter (position it with /sshs).")
        @ConfigEditorBoolean
        public Property<Boolean> rateHudEnabled;

        @ConfigOption(name = "Move HUD Panels", desc = "Opens the /sshs overlay editor to drag HUD panels around.")
        @ConfigEditorButton(buttonText = "Open")
        public Runnable openHudPositionEditor;

        HudCategory(SkyshardConfig config) {
            hudEnabled = bind(() -> config.hudEnabled, v -> {
                config.hudEnabled = v;
                config.save();
            });
            hudCorner = bind(() -> config.hudCorner, v -> {
                config.hudCorner = v;
                config.save();
            });
            rateHudEnabled = bind(() -> config.rateHudEnabled, v -> {
                config.rateHudEnabled = v;
                config.save();
            });
            openHudPositionEditor = () -> Minecraft.getInstance().setScreenAndShow(new HudPositionScreen(config));
        }
    }

    public static final class DataSyncCategory {
        @ConfigOption(name = "Data Source", desc = "Shard, fusion and rate data is sourced from skyshards.com.")
        @ConfigEditorInfoText(infoTitle = "Data Source")
        public String dataCredit = "";

        @ConfigOption(name = "Enable API sync",
                desc = "When enabled, periodically fetches shard data from the configured base URL. "
                        + "When disabled (or the fetch fails), the bundled offline data is used instead.")
        @ConfigEditorBoolean
        public Property<Boolean> apiSyncEnabled;

        @ConfigOption(name = "API base URL",
                desc = "Base URL the mod appends 'fusion-data.json' to when syncing. Change this if "
                        + "skyshards.com changes its data path, or point it at your own mirror.")
        @ConfigEditorText
        public Property<String> apiBaseUrl;

        @ConfigOption(name = "Sync interval (minutes)", desc = "How often shard/recipe data is re-synced from the API.")
        @ConfigEditorSlider(minValue = 1f, maxValue = 120f, minStep = 1f)
        public Property<Float> syncIntervalMinutes;

        DataSyncCategory(SkyshardConfig config) {
            apiSyncEnabled = bind(() -> config.apiSyncEnabled, v -> {
                config.apiSyncEnabled = v;
                config.save();
                SkyshardHelperClient.onApiSyncEnabledChanged();
            });
            // this fires on every keystroke, so no re-sync trigger here or it'd spam requests at
            // whatever partial URL is currently typed. picked up on the next scheduled sync.
            apiBaseUrl = bind(() -> config.apiBaseUrl, v -> {
                config.apiBaseUrl = v;
                config.save();
            });
            // The slider editor always works in Float, so Property<Integer> would fail to save.
            syncIntervalMinutes = bind(() -> (float) config.syncIntervalMinutes, v -> {
                config.syncIntervalMinutes = Math.round(v);
                config.save();
                SkyshardHelperClient.onSyncIntervalChanged();
            });
        }
    }

    public static final class ChatDetectionCategory {
        // MoulConfig has no free-form list editor, only text fields, so join/split on ";;"
        private static final String DELIMITER = " ;; ";

        @ConfigOption(name = "Chat detection patterns",
                desc = "Regular expressions used to detect shard-obtain chat messages (catches, fusion "
                        + "completions and Loot Share), separated by ';;'. Each pattern must contain a "
                        + "named group '(?<shard>...)' capturing the shard name; legacy formatting codes "
                        + "are stripped before matching, so patterns should assume clean text.")
        @ConfigEditorText
        public Property<String> chatRegexPatterns;

        ChatDetectionCategory(SkyshardConfig config) {
            chatRegexPatterns = bind(() -> String.join(DELIMITER, config.chatRegexPatterns), v -> {
                List<String> patterns = new ArrayList<>();
                for (String pattern : v.split("\\s*;;\\s*")) {
                    if (!pattern.isBlank()) {
                        patterns.add(pattern.trim());
                    }
                }
                config.chatRegexPatterns = patterns;
                config.save();
                SkyshardHelperClient.onChatPatternsChanged();
            });
        }
    }

    public static final class DevCategory {
        @ConfigOption(name = "Enable Missing Shards filter",
                desc = "Experimental: adds a 'Missing' filter/highlight to Browse Shards for shards you "
                        + "haven't identified yet, detected from Hypixel's Attributes menu. The ownership "
                        + "signal this relies on has proven unreliable before, so treat results with "
                        + "caution - off by default.")
        @ConfigEditorBoolean
        public Property<Boolean> missingShardsFeatureEnabled;

        @ConfigOption(name = "Enable Dev Version data",
                desc = "Experimental: syncs fusion data, perk descriptions and shard icons from the 'dev' "
                        + "branch of the SkyShards GitHub repo instead of 'master' - new shards/descriptions/"
                        + "icons prepared for a future update, ahead of skyshards.com. Unstable by nature "
                        + "(may change or disappear before release) - off by default.")
        @ConfigEditorBoolean
        public Property<Boolean> devVersionEnabled;

        DevCategory(SkyshardConfig config) {
            missingShardsFeatureEnabled = bind(() -> config.missingShardsFeatureEnabled, v -> {
                config.missingShardsFeatureEnabled = v;
                config.save();
            });
            devVersionEnabled = bind(() -> config.devVersionEnabled, v -> {
                config.devVersionEnabled = v;
                config.save();
                SkyshardHelperClient.onDevVersionChanged();
            });
        }
    }

    public static final class CalculatorCategory {
        @ConfigOption(name = "Ironman Profile",
                desc = "Auto-detected from the \"IRONMAN\" line on your SkyBlock scoreboard - no toggle or "
                        + "API key needed. Controls whether the Coins/Hour HUD panel and Bazaar tooltip "
                        + "price are offered, since Ironman characters can't use the Bazaar.")
        @ConfigEditorInfoText(infoTitle = "Ironman Profile")
        public String ironManStatus;

        @ConfigOption(name = "Exclude Chameleon",
                desc = "Treats the Chameleon shard as unobtainable in fusion calculations (matches "
                        + "skyshards.com's option of the same name).")
        @ConfigEditorBoolean
        public Property<Boolean> excludeChameleon;

        @ConfigOption(name = "Exclude Wooden Bait",
                desc = "Sharply reduces the assumed drop rate of Wooden Bait fishing shards, for players "
                        + "who don't want to rely on that method.")
        @ConfigEditorBoolean
        public Property<Boolean> noWoodenBait;

        @ConfigOption(name = "Compact Calculator Layout",
                desc = "Shrinks row heights and spacing in the K-menu calculator sidebar to fit more on "
                        + "screen at once.")
        @ConfigEditorBoolean
        public Property<Boolean> compactMode;

        @ConfigOption(name = "Browse Shards Icon Grid",
                desc = "Shows Browse Shards as a dense grid of icons (name/rarity/type on hover) instead "
                        + "of a one-per-row list, so many more shards fit on screen at once.")
        @ConfigEditorBoolean
        public Property<Boolean> browseIconGridMode;

        @ConfigOption(name = "Show perk tooltips in K-menu",
                desc = "Shows each shard's Attribute perk (title + description) as a hover tooltip in the "
                        + "Materials Needed and Fusion Tree cards too, not just Browse Shards.")
        @ConfigEditorBoolean
        public Property<Boolean> showPerkTooltipsInCalculator;

        @ConfigOption(name = "Show Bazaar price in tooltip",
                desc = "Adds the live Bazaar sell price to the Browse Shards hover tooltip. Hidden on "
                        + "Ironman profiles (see 'Ironman Profile' above), since Ironman characters can't "
                        + "use the Bazaar - NPC sell price support is planned but not yet implemented.")
        @ConfigEditorBoolean
        public Property<Boolean> showBazaarPriceInTooltip;

        CalculatorCategory(SkyshardConfig config) {
            ironManStatus = "Currently: " + (config.ironManView ? "Ironman" : "Normal");
            excludeChameleon = bind(() -> config.excludeChameleon, v -> {
                config.excludeChameleon = v;
                config.save();
            });
            noWoodenBait = bind(() -> config.noWoodenBait, v -> {
                config.noWoodenBait = v;
                config.save();
            });
            compactMode = bind(() -> config.compactMode, v -> {
                config.compactMode = v;
                config.save();
            });
            browseIconGridMode = bind(() -> config.browseIconGridMode, v -> {
                config.browseIconGridMode = v;
                config.save();
            });
            showPerkTooltipsInCalculator = bind(() -> config.showPerkTooltipsInCalculator, v -> {
                config.showPerkTooltipsInCalculator = v;
                config.save();
            });
            showBazaarPriceInTooltip = bind(() -> config.showBazaarPriceInTooltip, v -> {
                config.showBazaarPriceInTooltip = v;
                config.save();
            });
        }
    }

    public static final class IssuesCategory {
        @ConfigOption(name = "Found a bug or have a suggestion?",
                desc = "Report it on the mod's GitHub issues page.")
        @ConfigEditorInfoText(infoTitle = "Report an Issue")
        public String info = "";

        @ConfigOption(name = "Open Issues Page", desc = "Opens " + ISSUES_URL + " in your browser.")
        @ConfigEditorButton(buttonText = "Open")
        public Runnable openIssuesPage;

        IssuesCategory() {
            openIssuesPage = () -> Util.getPlatform().openUri(URI.create(ISSUES_URL));
        }
    }

    public static final class WaypointsCategory {
        @ConfigOption(name = "Waypoints", desc = "Not implemented yet - check back in a future update.")
        @ConfigEditorInfoText(infoTitle = "Coming Soon")
        public String info = "";
    }

    public static final class MiscCategory {
        @Category(name = "Dev", desc = "Features that are still being worked on - use with caution.")
        public DevCategory dev;

        @Category(name = "Issues", desc = "Report bugs or suggest features.")
        public IssuesCategory issues;

        // tried nesting this under an extra "Data" category first - MoulConfig just rendered it empty,
        // categories two levels deep don't work, only direct children do
        @Category(name = "Data Sync", desc = "Where shard/recipe data comes from and how often it refreshes.")
        public DataSyncCategory dataSync;

        @Category(name = "Chat Detection", desc = "Patterns used to recognize shard-obtain messages in chat.")
        public ChatDetectionCategory chatDetection;

        MiscCategory(SkyshardConfig config) {
            this.dev = new DevCategory(config);
            this.issues = new IssuesCategory();
            this.dataSync = new DataSyncCategory(config);
            this.chatDetection = new ChatDetectionCategory(config);
        }
    }
}
