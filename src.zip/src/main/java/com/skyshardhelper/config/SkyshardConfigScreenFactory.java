package com.skyshardhelper.config;

import io.github.notenoughupdates.moulconfig.gui.CloseEventListener;
import io.github.notenoughupdates.moulconfig.gui.GuiContext;
import io.github.notenoughupdates.moulconfig.gui.GuiElementComponent;
import io.github.notenoughupdates.moulconfig.gui.MoulConfigEditor;
import io.github.notenoughupdates.moulconfig.platform.MoulConfigScreenComponent;
import io.github.notenoughupdates.moulconfig.processor.ConfigProcessorDriver;
import io.github.notenoughupdates.moulconfig.processor.MoulConfigProcessor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class SkyshardConfigScreenFactory {
    private SkyshardConfigScreenFactory() {
    }

    public static Screen build(Screen parent, SkyshardConfig config) {
        SkyshardMoulConfig view = new SkyshardMoulConfig(config);
        MoulConfigProcessor<SkyshardMoulConfig> processor = MoulConfigProcessor.withDefaults(view);
        // withDefaults() only registers editors, still need this to actually walk the fields into
        // categories. checkExpose off because these fields aren't Gson fields.
        ConfigProcessorDriver driver = new ConfigProcessorDriver(processor);
        driver.checkExpose = false;
        driver.processConfig(view);
        MoulConfigEditor<SkyshardMoulConfig> editor = new MoulConfigEditor<>(processor);
        GuiContext context = new GuiContext(new GuiElementComponent(editor));
        return new SkyshardMoulScreen(Component.translatable("config.skyshardhelper.title"), context, parent);
    }

    // stock MoulConfigScreenComponent doesn't navigate back on close, have to do it ourselves
    private static final class SkyshardMoulScreen extends MoulConfigScreenComponent {
        SkyshardMoulScreen(Component title, GuiContext guiContext, Screen previousScreen) {
            super(title, guiContext, previousScreen);
        }

        @Override
        public void onClose() {
            if (getGuiContext().onBeforeClose() != CloseEventListener.CloseAction.NO_OBJECTIONS_TO_CLOSE) {
                return;
            }
            this.minecraft.setScreenAndShow(getPreviousScreen());
        }
    }
}
