package com.skyshardhelper.config;

public enum KuudraTier {
    NONE,
    T1,
    T2,
    T3,
    T4,
    T5
}
