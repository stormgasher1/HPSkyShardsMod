package com.skyshardhelper.service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

// Caches live Bazaar prices for shard products, used by the coins/hour HUD panel.
public final class BazaarPriceCache {
    private static final Logger LOGGER = LoggerFactory.getLogger("skyshardhelper");
    private static final String BAZAAR_URL = "https://api.hypixel.net/v2/skyblock/bazaar";
    private static final String SHARD_PRODUCT_PREFIX = "SHARD_";

    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();
    private final Gson gson = new Gson();

    private volatile Map<String, Double> sellPrices = Map.of();
    private volatile Map<String, Double> buyPrices = Map.of();

    // apiKey may be null/blank, in which case we just hit the public endpoint unauthenticated.
    public void refresh(String apiKey) {
        HttpRequest.Builder requestBuilder = HttpRequest.newBuilder(URI.create(BAZAAR_URL))
                .timeout(Duration.ofSeconds(8))
                .GET();
        if (apiKey != null && !apiKey.isBlank()) {
            requestBuilder.header("API-Key", apiKey.trim());
        }
        HttpRequest request = requestBuilder.build();
        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(this::parseResponse)
                .exceptionally(ex -> {
                    LOGGER.warn("Skyshard Helper: failed to fetch Bazaar prices: {}", ex.getMessage());
                    return null;
                });
    }

    private void parseResponse(HttpResponse<String> response) {
        if (response.statusCode() != 200) {
            LOGGER.warn("Skyshard Helper: Bazaar API returned HTTP {}", response.statusCode());
            return;
        }
        try {
            JsonObject root = gson.fromJson(response.body(), JsonObject.class);
            JsonObject products = root != null ? root.getAsJsonObject("products") : null;
            if (products == null) {
                LOGGER.warn("Skyshard Helper: Bazaar API response had no 'products' object");
                return;
            }
            Map<String, Double> sells = new HashMap<>();
            Map<String, Double> buys = new HashMap<>();
            for (String productId : products.keySet()) {
                if (!productId.startsWith(SHARD_PRODUCT_PREFIX)) {
                    continue;
                }
                JsonObject quickStatus = products.getAsJsonObject(productId).getAsJsonObject("quick_status");
                if (quickStatus == null) {
                    continue;
                }
                if (quickStatus.has("sellPrice")) {
                    sells.put(productId, quickStatus.get("sellPrice").getAsDouble());
                }
                if (quickStatus.has("buyPrice")) {
                    buys.put(productId, quickStatus.get("buyPrice").getAsDouble());
                }
            }
            sellPrices = sells;
            buyPrices = buys;
            LOGGER.info("Skyshard Helper: cached {} shard Bazaar sell prices, {} buy prices", sells.size(), buys.size());
        } catch (JsonSyntaxException e) {
            LOGGER.warn("Skyshard Helper: failed to parse Bazaar API response: {}", e.getMessage());
        }
    }

    // Returns 0 if unknown or not tradable on the Bazaar.
    public double sellPriceFor(String internalId) {
        if (internalId == null) {
            return 0;
        }
        return sellPrices.getOrDefault(internalId, 0.0);
    }

    public double buyPriceFor(String internalId) {
        if (internalId == null) {
            return 0;
        }
        return buyPrices.getOrDefault(internalId, 0.0);
    }
}
