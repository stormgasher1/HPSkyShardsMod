package com.skyshardhelper.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.skyshardhelper.config.SkyshardConfig;
import com.skyshardhelper.data.FusionData;
import com.skyshardhelper.data.FusionDataParser;
import com.skyshardhelper.data.Recipe;
import com.skyshardhelper.data.Shard;
import com.skyshardhelper.data.ShardPerkInfo;
import com.skyshardhelper.data.ShardPerkInfoDeserializer;
import com.skyshardhelper.data.ShardUsage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

// Holds the current shard/recipe dataset. Starts from the bundled fallback, can refresh from the API.
public final class ShardRepository {
    private static final Logger LOGGER = LoggerFactory.getLogger("skyshardhelper");
    private static final String FUSION_DATA_RESOURCE_PATH = "/data/skyshardhelper/shards/fusion-data.json";
    private static final String RATES_RESOURCE_PATH = "/data/skyshardhelper/shards/rates.json";
    private static final String PERKS_RESOURCE_PATH = "/data/skyshardhelper/shards/desc.json";
    private static final Type PERKS_TYPE = new TypeToken<Map<String, ShardPerkInfo>>() {
    }.getType();

    private final ShardApiService apiService = new ShardApiService();
    private final Gson gson = new GsonBuilder()
            .registerTypeAdapter(ShardPerkInfo.class, new ShardPerkInfoDeserializer())
            .create();

    private volatile FusionData current = FusionData.empty();
    private volatile Map<String, ShardPerkInfo> perks = Map.of();

    // Fixed at startup from the bundled data - isDevShard() diffs against this once a dev sync adds ids we don't know.
    private volatile Set<String> bundledShardIds = Set.of();

    // usedIn() gets called per rendered node every frame while the Used-In screen is open, so cache the reverse index.
    private FusionData usageIndexSource;
    private Map<String, List<ShardUsage>> usageIndex = Map.of();

    public void loadFallback() {
        try (InputStream fusionStream = ShardRepository.class.getResourceAsStream(FUSION_DATA_RESOURCE_PATH);
             InputStream ratesStream = ShardRepository.class.getResourceAsStream(RATES_RESOURCE_PATH)) {
            if (fusionStream == null || ratesStream == null) {
                LOGGER.error("Skyshard Helper: bundled shard data resource is missing (fusion-data.json/rates.json)");
                return;
            }
            FusionData data = FusionDataParser.parse(gson,
                    new InputStreamReader(fusionStream, StandardCharsets.UTF_8),
                    new InputStreamReader(ratesStream, StandardCharsets.UTF_8));
            if (data != null && data.shards() != null) {
                current = data;
                bundledShardIds = Set.copyOf(data.shards().keySet());
                LOGGER.info("Skyshard Helper: loaded {} shards from bundled offline data", data.shards().size());
            }
        } catch (IOException e) {
            LOGGER.error("Skyshard Helper: failed to read bundled fallback resource", e);
        }

        try (InputStream perksStream = ShardRepository.class.getResourceAsStream(PERKS_RESOURCE_PATH)) {
            if (perksStream == null) {
                LOGGER.warn("Skyshard Helper: bundled shard perk descriptions (desc.json) are missing");
                return;
            }
            Map<String, ShardPerkInfo> loaded = gson.fromJson(
                    new InputStreamReader(perksStream, StandardCharsets.UTF_8), PERKS_TYPE);
            if (loaded != null) {
                perks = loaded;
                LOGGER.info("Skyshard Helper: loaded {} shard perk descriptions", loaded.size());
            }
        } catch (IOException e) {
            LOGGER.error("Skyshard Helper: failed to read bundled perk descriptions", e);
        }
    }

    public Optional<ShardPerkInfo> findPerk(String shardId) {
        return Optional.ofNullable(perks.get(shardId));
    }

    public void refreshFromApi(SkyshardConfig config) {
        if (!config.apiSyncEnabled) {
            return;
        }
        apiService.fetchFusionData(config.apiBaseUrl, config.devVersionEnabled).thenAccept(result -> result.ifPresentOrElse(
                data -> {
                    current = data;
                    LOGGER.info("Skyshard Helper: synced {} shards from {}", data.shards().size(),
                            config.devVersionEnabled ? "the SkyShards dev branch" : config.apiBaseUrl);
                },
                () -> LOGGER.warn("Skyshard Helper: API sync failed, keeping last known/fallback data ({} shards)",
                        current.shards().size())
        ));
        apiService.fetchPerkDescriptions(config.devVersionEnabled).thenAccept(result -> result.ifPresentOrElse(
                loaded -> {
                    perks = loaded;
                    LOGGER.info("Skyshard Helper: synced {} shard perk descriptions", loaded.size());
                },
                () -> LOGGER.warn("Skyshard Helper: perk description sync failed, keeping last known/bundled data ({} entries)",
                        perks.size())
        ));
    }

    public Collection<Shard> all() {
        return current.shards().values();
    }

    public Optional<Shard> findById(String id) {
        return Optional.ofNullable(current.shards().get(id));
    }

    // True if this shard only exists because a dev-branch sync pulled it in.
    public boolean isDevShard(String shardId) {
        return !bundledShardIds.contains(shardId);
    }

    public List<Recipe> recipesFor(String shardId) {
        return current.recipes().getOrDefault(shardId, List.of());
    }

    public List<ShardUsage> usedIn(String shardId) {
        return usageIndex(current).getOrDefault(shardId, List.of());
    }

    private Map<String, List<ShardUsage>> usageIndex(FusionData data) {
        if (usageIndexSource == data) {
            return usageIndex;
        }
        Map<String, List<ShardUsage>> built = new HashMap<>();
        for (Map.Entry<String, List<Recipe>> entry : data.recipes().entrySet()) {
            for (Recipe recipe : entry.getValue()) {
                ShardUsage usage = new ShardUsage(entry.getKey(), recipe);
                String input1 = recipe.inputs()[0];
                String input2 = recipe.inputs()[1];
                built.computeIfAbsent(input1, k -> new ArrayList<>()).add(usage);
                // avoid double-adding self-fusion recipes (input1 == input2)
                if (!input2.equals(input1)) {
                    built.computeIfAbsent(input2, k -> new ArrayList<>()).add(usage);
                }
            }
        }
        usageIndex = built;
        usageIndexSource = data;
        return built;
    }

    public Optional<Shard> findByNameIgnoreCase(String name) {
        return current.shards().values().stream()
                .filter(shard -> shard.name().equalsIgnoreCase(name))
                .findFirst();
    }

    private record ScoredShard(Shard shard, int rank) {
    }

    public List<Shard> search(String query) {
        String needle = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (needle.isEmpty()) {
            return List.copyOf(all());
        }
        return current.shards().values().stream()
                .map(shard -> new ScoredShard(shard, rank(shard, needle)))
                .filter(scored -> scored.rank() < Integer.MAX_VALUE)
                .sorted(Comparator.comparingInt(ScoredShard::rank).thenComparing(scored -> scored.shard().name(), String.CASE_INSENSITIVE_ORDER))
                .map(ScoredShard::shard)
                .toList();
    }

    // lower = better match, so the suggestion dropdown shows the closest hits first
    private int rank(Shard shard, String needle) {
        String name = shard.name().toLowerCase(Locale.ROOT);
        if (name.equals(needle)) {
            return 0;
        }
        if (name.startsWith(needle)) {
            return 1;
        }
        if (name.contains(needle)) {
            return 2;
        }
        if (shard.family().toLowerCase(Locale.ROOT).contains(needle) || shard.type().toLowerCase(Locale.ROOT).contains(needle)) {
            return 3;
        }
        if (matchesPerk(shard.id(), needle)) {
            return 4;
        }
        return Integer.MAX_VALUE;
    }

    private boolean matchesPerk(String shardId, String lowercaseNeedle) {
        ShardPerkInfo perk = perks.get(shardId);
        return perk != null
                && ((perk.title() != null && perk.title().toLowerCase(Locale.ROOT).contains(lowercaseNeedle))
                || (perk.description() != null && perk.description().toLowerCase(Locale.ROOT).contains(lowercaseNeedle)));
    }
}
