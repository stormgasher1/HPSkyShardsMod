package com.skyshardhelper.service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.skyshardhelper.data.FusionData;
import com.skyshardhelper.data.FusionDataParser;
import com.skyshardhelper.data.ShardPerkInfo;
import com.skyshardhelper.data.ShardPerkInfoDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.StringReader;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

// Pulls shard/recipe/rate/perk data from skyshards.com, falls back to the bundled copy on failure.
public final class ShardApiService {
    private static final Logger LOGGER = LoggerFactory.getLogger("skyshardhelper");
    private static final String DATA_FILE_NAME = "fusion-data.json";
    private static final String RATES_FILE_NAME = "rates.json";
    // dev branch data isn't mirrored to skyshards.com, goes straight to GitHub instead
    private static final String GITHUB_RAW_BASE = "https://raw.githubusercontent.com/Campionnn/SkyShards/";
    private static final String DEV_DATA_BASE_URL = GITHUB_RAW_BASE + "dev/public/";
    private static final String MASTER_DESC_URL = GITHUB_RAW_BASE + "master/src/desc.json";
    private static final String DEV_DESC_URL = GITHUB_RAW_BASE + "dev/src/desc.json";
    private static final Type PERKS_TYPE = new TypeToken<Map<String, ShardPerkInfo>>() {
    }.getType();

    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();
    private final Gson gson = new GsonBuilder()
            .registerTypeAdapter(ShardPerkInfo.class, new ShardPerkInfoDeserializer())
            .create();

    public CompletableFuture<Optional<FusionData>> fetchFusionData(String baseUrl, boolean devVersionEnabled) {
        String normalizedBase;
        if (devVersionEnabled) {
            normalizedBase = DEV_DATA_BASE_URL;
        } else {
            try {
                normalizedBase = baseUrl.endsWith("/") ? baseUrl : baseUrl + "/";
                URI.create(normalizedBase);
            } catch (IllegalArgumentException e) {
                LOGGER.warn("Invalid Skyshard Helper API base URL '{}': {}", baseUrl, e.getMessage());
                return CompletableFuture.completedFuture(Optional.empty());
            }
        }

        CompletableFuture<HttpResponse<String>> fusionRequest = fetch(normalizedBase + DATA_FILE_NAME);
        CompletableFuture<HttpResponse<String>> ratesRequest = fetch(normalizedBase + RATES_FILE_NAME);

        return fusionRequest.thenCombine(ratesRequest, this::parseResponses)
                .exceptionally(ex -> {
                    LOGGER.warn("Skyshard Helper: failed to fetch shard data from {}: {}", normalizedBase, ex.getMessage());
                    return Optional.empty();
                });
    }

    public CompletableFuture<Optional<Map<String, ShardPerkInfo>>> fetchPerkDescriptions(boolean devVersionEnabled) {
        return fetch(devVersionEnabled ? DEV_DESC_URL : MASTER_DESC_URL)
                .thenApply(response -> {
                    if (response.statusCode() != 200) {
                        LOGGER.warn("Skyshard Helper: perk description endpoint returned HTTP {}", response.statusCode());
                        return Optional.<Map<String, ShardPerkInfo>>empty();
                    }
                    try {
                        Map<String, ShardPerkInfo> perks = gson.fromJson(response.body(), PERKS_TYPE);
                        return perks != null ? Optional.of(perks) : Optional.<Map<String, ShardPerkInfo>>empty();
                    } catch (JsonSyntaxException e) {
                        LOGGER.warn("Skyshard Helper: failed to parse perk descriptions JSON: {}", e.getMessage());
                        return Optional.<Map<String, ShardPerkInfo>>empty();
                    }
                })
                .exceptionally(ex -> {
                    LOGGER.warn("Skyshard Helper: failed to fetch perk descriptions: {}", ex.getMessage());
                    return Optional.empty();
                });
    }

    // raw.githubusercontent.com drops connections a lot, worth a couple retries
    private static final int MAX_ATTEMPTS = 3;
    private static final long RETRY_DELAY_MILLIS = 400;

    private CompletableFuture<HttpResponse<String>> fetch(String url) {
        return fetch(url, MAX_ATTEMPTS);
    }

    private CompletableFuture<HttpResponse<String>> fetch(String url, int attemptsLeft) {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(8))
                .GET()
                .build();
        return client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .handle((response, ex) -> {
                    if (ex == null) {
                        return CompletableFuture.completedFuture(response);
                    }
                    if (attemptsLeft <= 1) {
                        CompletableFuture<HttpResponse<String>> failed = new CompletableFuture<>();
                        failed.completeExceptionally(ex);
                        return failed;
                    }
                    LOGGER.debug("Skyshard Helper: retrying fetch of {} after {}", url, ex.getMessage());
                    return CompletableFuture.supplyAsync(() -> (HttpResponse<String>) null,
                                    CompletableFuture.delayedExecutor(RETRY_DELAY_MILLIS, TimeUnit.MILLISECONDS))
                            .thenCompose(ignored -> fetch(url, attemptsLeft - 1));
                })
                .thenCompose(future -> future);
    }

    private Optional<FusionData> parseResponses(HttpResponse<String> fusionResponse, HttpResponse<String> ratesResponse) {
        if (fusionResponse.statusCode() != 200 || ratesResponse.statusCode() != 200) {
            LOGGER.warn("Skyshard Helper: shard data endpoints returned HTTP {} / {}",
                    fusionResponse.statusCode(), ratesResponse.statusCode());
            return Optional.empty();
        }
        try {
            FusionData data = FusionDataParser.parse(gson,
                    new StringReader(fusionResponse.body()),
                    new StringReader(ratesResponse.body()));
            if (data == null || data.shards() == null) {
                LOGGER.warn("Skyshard Helper: shard data endpoint returned an empty/unexpected payload");
                return Optional.empty();
            }
            return Optional.of(data);
        } catch (JsonSyntaxException e) {
            LOGGER.warn("Skyshard Helper: failed to parse shard data JSON: {}", e.getMessage());
            return Optional.empty();
        }
    }
}
