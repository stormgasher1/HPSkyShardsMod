package com.skyshardhelper.scoreboard;

import com.skyshardhelper.config.SkyshardConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;

import java.util.Collection;
import java.util.Locale;

// Scans the sidebar scoreboard for an "IRONMAN" line and writes the result into
// SkyshardConfig.ironManView. All local, no API key needed - that's the whole point.
public final class IronmanScoreboardScanner {
    private static final int SCAN_INTERVAL_TICKS = 20;

    private int ticksUntilScan;

    private IronmanScoreboardScanner() {
    }

    public static void register(SkyshardConfig config) {
        IronmanScoreboardScanner scanner = new IronmanScoreboardScanner();
        ClientTickEvents.END_CLIENT_TICK.register(client -> scanner.tick(client, config));
    }

    private void tick(Minecraft client, SkyshardConfig config) {
        if (client.level == null || client.player == null) {
            return;
        }
        if (ticksUntilScan-- > 0) {
            return;
        }
        ticksUntilScan = SCAN_INTERVAL_TICKS;

        Boolean ironman = detectIronman(client);
        if (ironman != null && config.ironManView != ironman) {
            config.ironManView = ironman;
            config.save();
        }
    }

    // null means there's no sidebar to read yet (e.g. between worlds) - caller leaves the old value alone then
    private static Boolean detectIronman(Minecraft client) {
        Scoreboard scoreboard = client.level.getScoreboard();
        Objective sidebar = scoreboard.getDisplayObjective(DisplaySlot.SIDEBAR);
        if (sidebar == null) {
            return null;
        }
        Collection<PlayerScoreEntry> entries = scoreboard.listPlayerScores(sidebar);
        if (entries.isEmpty()) {
            return null;
        }
        for (PlayerScoreEntry entry : entries) {
            if (entry.isHidden()) {
                continue;
            }
            PlayerTeam team = scoreboard.getPlayersTeam(entry.owner());
            Component line = team != null ? PlayerTeam.formatNameForTeam(team, entry.ownerName()) : entry.ownerName();
            if (line.getString().toUpperCase(Locale.ROOT).contains("IRONMAN")) {
                return true;
            }
        }
        return false;
    }
}
